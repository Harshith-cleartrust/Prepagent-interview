"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Sidebar } from "@/components/sidebar"

interface DashboardLayoutProps {
  children: React.ReactNode
  requiredRole: "admin" | "user"
}

export function DashboardLayout({ children, requiredRole }: DashboardLayoutProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [role, setRole] = useState<string | null>(null)
  const [username, setUsername] = useState<string>("")

  useEffect(() => {
    // Function to get cookie value
    const getCookie = (name: string): string | null => {
      const cookies = document.cookie.split("; ")
      const cookie = cookies.find((c) => c.startsWith(`${name}=`))
      return cookie ? cookie.split("=")[1] : null
    }

    // Get role from cookie
    const userRole = getCookie("role")
    const userName = getCookie("username") || "User"

    console.log("Dashboard Layout - Detected role:", userRole)
    console.log("Dashboard Layout - Detected username:", userName)

    setRole(userRole)
    setUsername(userName)

    // Check if user has the required role
    if (!userRole) {
      console.log("No role found, redirecting to login")
      router.push("/login")
    } else if (userRole !== requiredRole) {
      console.log(`Role mismatch: ${userRole} vs required ${requiredRole}, redirecting`)
      router.push(userRole === "admin" ? "/admin/dashboard" : "/user/dashboard")
    } else {
      console.log("Role matches required role, rendering dashboard")
      setIsLoading(false)
    }
  }, [router, requiredRole])

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-purple-50">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-purple-200 border-t-purple-700"></div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-purple-50">
      <Sidebar role={requiredRole as "admin" | "user"} username={username} />
      <div className="flex-1 md:ml-64">
        <main className="container mx-auto p-4 md:p-6">{children}</main>
      </div>
    </div>
  )
}
