"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  BarChart3,
  BookOpen,
  ClipboardList,
  Home,
  LogOut,
  Settings,
  Users,
  PlusCircle,
  FileText,
  User,
  History,
  Award,
  Menu,
  X,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

interface SidebarProps {
  role: "admin" | "user"
  username: string
}

export function Sidebar({ role, username }: SidebarProps) {
  const pathname = usePathname()
  const [isMobileOpen, setIsMobileOpen] = useState(false)

  // Close sidebar when route changes on mobile
  useEffect(() => {
    setIsMobileOpen(false)
  }, [pathname])

  const adminLinks = [
    {
      name: "Dashboard",
      href: "/admin/dashboard",
      icon: Home,
    },
    {
      name: "Create Test",
      href: "/admin/create-test",
      icon: PlusCircle,
    },
    {
      name: "Test Management",
      href: "/admin/tests",
      icon: ClipboardList,
    },
    {
      name: "User Management",
      href: "/admin/users",
      icon: Users,
    },
    {
      name: "Analytics",
      href: "/admin/analytics",
      icon: BarChart3,
    },
    {
      name: "Reports",
      href: "/admin/reports",
      icon: FileText,
    },
    {
      name: "Settings",
      href: "/admin/settings",
      icon: Settings,
    },
  ]

  const userLinks = [
    {
      name: "Dashboard",
      href: "/user/dashboard",
      icon: Home,
    },
    {
      name: "Active Tests",
      href: "/user/active-tests",
      icon: BookOpen,
    },
    {
      name: "Test History",
      href: "/user/history",
      icon: History,
    },
    {
      name: "Performance",
      href: "/user/performance",
      icon: Award,
    },
    {
      name: "Profile",
      href: "/user/profile",
      icon: User,
    },
  ]

  const links = role === "admin" ? adminLinks : userLinks

  const handleLogout = () => {
    // Clear cookies
    document.cookie = "role=; path=/; max-age=0"
    document.cookie = "user=; path=/; max-age=0"
    // Redirect to login
    window.location.href = "/login"
  }

  return (
    <>
      {/* Mobile Menu Button */}
      <Button
        variant="ghost"
        size="icon"
        className="fixed top-4 left-4 z-50 md:hidden"
        onClick={() => setIsMobileOpen(!isMobileOpen)}
      >
        {isMobileOpen ? <X className="h-6 w-6 text-purple-800" /> : <Menu className="h-6 w-6 text-purple-800" />}
      </Button>

      {/* Sidebar */}
      <div
        className={cn(
          "fixed inset-y-0 left-0 z-40 flex w-64 flex-col bg-white shadow-lg transition-transform duration-300 ease-in-out",
          isMobileOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0",
        )}
      >
        <div className="flex h-16 items-center border-b px-6">
          <Link href={role === "admin" ? "/admin/dashboard" : "/user/dashboard"} className="flex items-center gap-2">
            <div className="rounded-full bg-gradient-to-r from-purple-600 to-purple-800 p-1.5 shadow-md">
              <BookOpen className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl font-bold text-purple-800">SAMAJH</span>
          </Link>
        </div>

        <ScrollArea className="flex-1 px-4 py-6">
          <nav className="flex flex-col gap-2">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                  pathname === link.href
                    ? "bg-purple-100 text-purple-800"
                    : "text-gray-600 hover:bg-purple-50 hover:text-purple-800",
                )}
              >
                <link.icon className="h-5 w-5" />
                {link.name}
              </Link>
            ))}
          </nav>
        </ScrollArea>

        <div className="border-t p-4">
          <div className="flex items-center gap-3 pb-4">
            <Avatar>
              <AvatarFallback className="bg-purple-200 text-purple-800">
                {username.substring(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="text-sm font-medium">{username}</p>
              <p className="text-xs text-gray-500 capitalize">{role}</p>
            </div>
          </div>
          <Button
            variant="outline"
            className="w-full justify-start gap-2 border-purple-200 text-purple-800 hover:bg-purple-50 hover:text-purple-900"
            onClick={handleLogout}
          >
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>
    </>
  )
}
