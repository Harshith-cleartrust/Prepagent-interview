"use server"

import { cookies } from "next/headers"
import { supabaseServer } from "@/lib/supabase/server"
import type { TestResult } from "@/lib/types"
import { revalidatePath } from "next/cache"
import { analyzeSkillGaps, generateRecommendations } from "@/lib/analytics-service"

export async function submitTestResult(formData: FormData) {
  const userId = cookies().get("user_id")?.value

  if (!userId) {
    return { error: "Not authenticated" }
  }

  const testId = formData.get("testId") as string
  const answersJson = formData.get("answers") as string
  const timeTaken = Number.parseInt(formData.get("timeTaken") as string)
  const startedAt = formData.get("startedAt") as string

  if (!testId || !answersJson || !timeTaken || !startedAt) {
    return { error: "Missing required fields" }
  }

  let answers: Record<string, number>
  try {
    answers = JSON.parse(answersJson)
  } catch (err) {
    return { error: "Invalid answers format" }
  }

  try {
    // Get the test questions to calculate score
    const { data: questions, error: questionsError } = await supabaseServer
      .from("questions")
      .select("id, correct_answer")
      .eq("test_id", testId)

    if (questionsError) {
      console.error("Error fetching questions:", questionsError)
      return { error: "Failed to fetch questions" }
    }

    // Calculate score
    let correctCount = 0
    for (const question of questions) {
      if (answers[question.id] === question.correct_answer) {
        correctCount++
      }
    }

    const score = Math.round((correctCount / questions.length) * 100)

    // Update user_tests status
    await supabaseServer.from("user_tests").update({ status: "completed" }).eq("user_id", userId).eq("test_id", testId)

    // Check if result already exists
    const { data: existingResult } = await supabaseServer
      .from("test_results")
      .select("id")
      .eq("user_id", userId)
      .eq("test_id", testId)
      .single()

    if (existingResult) {
      // Update existing result
      const { error } = await supabaseServer
        .from("test_results")
        .update({
          score,
          answers,
          time_taken: timeTaken,
          started_at: startedAt,
          completed_at: new Date().toISOString(),
        })
        .eq("id", existingResult.id)

      if (error) {
        console.error("Error updating test result:", error)
        return { error: "Failed to update test result" }
      }
    } else {
      // Create new result
      const { error } = await supabaseServer.from("test_results").insert([
        {
          user_id: userId,
          test_id: testId,
          score,
          answers,
          time_taken: timeTaken,
          started_at: startedAt,
          completed_at: new Date().toISOString(),
        },
      ])

      if (error) {
        console.error("Error creating test result:", error)
        return { error: "Failed to create test result" }
      }
    }

    revalidatePath("/user/history")
    revalidatePath("/user/test-results")
    return { success: true, resultId: existingResult?.id }
  } catch (err) {
    console.error("Error in submitTestResult:", err)
    return { error: "An error occurred while submitting the test result" }
  }
}

export async function getTestResults(userId?: string): Promise<TestResult[]> {
  const currentUserId = cookies().get("user_id")?.value
  const role = cookies().get("role")?.value

  if (!currentUserId) {
    return []
  }

  // If no userId is provided, use the current user's ID
  const targetUserId = userId || currentUserId

  // Check permissions
  if (role !== "admin" && targetUserId !== currentUserId) {
    return [] // Users can only view their own results
  }

  try {
    const { data, error } = await supabaseServer
      .from("test_results")
      .select(`
        *,
        tests (
          id,
          title,
          topic,
          duration
        )
      `)
      .eq("user_id", targetUserId)
      .order("completed_at", { ascending: false })

    if (error) {
      console.error("Error fetching test results:", error)
      return []
    }

    return data as TestResult[]
  } catch (err) {
    console.error("Error in getTestResults:", err)
    return []
  }
}

export async function getTestResult(testId: string, userId?: string): Promise<TestResult | null> {
  const currentUserId = cookies().get("user_id")?.value
  const role = cookies().get("role")?.value

  if (!currentUserId) {
    return null
  }

  // If no userId is provided, use the current user's ID
  const targetUserId = userId || currentUserId

  // Check permissions
  if (role !== "admin" && targetUserId !== currentUserId) {
    return null // Users can only view their own results
  }

  try {
    const { data, error } = await supabaseServer
      .from("test_results")
      .select(`
        *,
        tests (
          id,
          title,
          topic,
          duration
        ),
        users (
          id,
          username,
          email
        )
      `)
      .eq("user_id", targetUserId)
      .eq("test_id", testId)
      .single()

    if (error) {
      console.error("Error fetching test result:", error)
      return null
    }

    return data as TestResult
  } catch (err) {
    console.error("Error in getTestResult:", err)
    return null
  }
}

export async function getUserPerformanceData() {
  const userId = cookies().get("user_id")?.value

  if (!userId) {
    return null
  }

  try {
    console.log("Fetching performance data for user:", userId)

    // Get completed tests count
    const { count: testsCompleted, error: testsError } = await supabaseServer
      .from("test_results")
      .select("*", { count: "exact", head: true })
      .eq("user_id", userId)

    if (testsError) {
      console.error("Error fetching completed tests:", testsError)
      return null
    }

    console.log("Tests completed:", testsCompleted)

    // If no tests completed, return empty data
    if (!testsCompleted || testsCompleted === 0) {
      return {
        performanceData: [],
        topicPerformance: [],
        skillGaps: [],
        recommendations: [
          "Take your first test to see personalized recommendations.",
          "Explore available tests in different topics to assess your skills.",
          "Complete tests regularly to track your progress over time.",
        ],
        stats: {
          testsCompleted: 0,
          averageScore: 0,
          improvement: 0,
        },
        testResults: [],
      }
    }

    // Get average score and test results
    const { data: scores, error: scoresError } = await supabaseServer
      .from("test_results")
      .select(`
        id, 
        score, 
        completed_at, 
        test_id, 
        answers,
        tests (
          id,
          title,
          topic,
          duration
        )
      `)
      .eq("user_id", userId)
      .order("completed_at", { ascending: false })

    if (scoresError) {
      console.error("Error fetching scores:", scoresError)
      return null
    }

    console.log("Scores data:", scores)

    const averageScore =
      scores.length > 0 ? Math.round(scores.reduce((sum, result) => sum + result.score, 0) / scores.length) : 0

    // Calculate improvement over the last 30 days
    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

    const recentScores = scores.filter((score) => new Date(score.completed_at) >= thirtyDaysAgo)
    const recentAverageScore =
      recentScores.length > 0
        ? Math.round(recentScores.reduce((sum, result) => sum + result.score, 0) / recentScores.length)
        : averageScore

    const improvement = averageScore > 0 ? Math.round(((recentAverageScore - averageScore) / averageScore) * 100) : 0

    // Get topic performance
    const topicScores: Record<string, { totalScore: number; count: number }> = {}

    scores.forEach((result) => {
      const topic = result.tests?.topic || "Unknown"
      if (!topicScores[topic]) {
        topicScores[topic] = { totalScore: 0, count: 0 }
      }
      topicScores[topic].totalScore += result.score
      topicScores[topic].count++
    })

    const topicPerformance = Object.entries(topicScores).map(([topic, data]) => ({
      topic,
      score: Math.round(data.totalScore / data.count),
      tests: data.count,
    }))

    console.log("Topic performance:", topicPerformance)

    // Generate skill gaps based on topic performance
    const skillGapsData = {
      testResults: scores,
      topicPerformance,
      userAnswers: scores.reduce((acc, result) => {
        return { ...acc, ...result.answers }
      }, {}),
    }

    const skillGaps = await analyzeSkillGaps(skillGapsData)
    console.log("Skill gaps:", skillGaps)

    // Generate recommendations
    const recommendations = await generateRecommendations(topicPerformance)
    console.log("Recommendations:", recommendations)

    // Generate performance data for chart
    const last6Months = Array.from({ length: 6 }, (_, i) => {
      const date = new Date()
      date.setMonth(date.getMonth() - i)
      return {
        month: date.toLocaleString("default", { month: "short" }),
        date: date,
      }
    }).reverse()

    const performanceData = last6Months.map(({ month, date }) => {
      const monthStart = new Date(date.getFullYear(), date.getMonth(), 1)
      const monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0)

      const monthScores = scores.filter((score) => {
        const scoreDate = new Date(score.completed_at)
        return scoreDate >= monthStart && scoreDate <= monthEnd
      })

      const avgScore =
        monthScores.length > 0
          ? Math.round(monthScores.reduce((sum, score) => sum + score.score, 0) / monthScores.length)
          : 0

      return {
        month,
        score: avgScore,
      }
    })

    console.log("Performance data:", performanceData)

    return {
      performanceData,
      topicPerformance,
      skillGaps,
      recommendations,
      stats: {
        testsCompleted: testsCompleted || 0,
        averageScore: averageScore || 0,
        improvement: improvement || 0,
      },
      testResults: scores,
    }
  } catch (error) {
    console.error("Error fetching user performance data:", error)
    return null
  }
}
