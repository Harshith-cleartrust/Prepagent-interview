"use server"

import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { supabaseServer } from "@/lib/supabase/server"
import type { User } from "@/lib/types"

export async function login(formData: FormData) {
  const email = formData.get("email") as string
  const password = formData.get("password") as string

  if (!email || !password) {
    return { error: "Email and password are required" }
  }

  try {
    console.log("Attempting login for:", email)

    // Query the user from the database
    const { data: user, error } = await supabaseServer
      .from("users")
      .select("*")
      .or(`email.eq.${email},username.eq.${email}`)
      .single()

    if (error) {
      console.error("Supabase query error:", error)
      return { error: "Invalid email or password" }
    }

    if (!user) {
      console.log("No user found with email/username:", email)
      return { error: "Invalid email or password" }
    }

    // In a real app, you would hash and compare passwords
    // This is a simplified version for demonstration
    if (user.password !== password) {
      console.log("Password mismatch for user:", email)
      return { error: "Invalid email or password" }
    }

    // Update last login time
    const { error: updateError } = await supabaseServer
      .from("users")
      .update({ last_login: new Date().toISOString() })
      .eq("id", user.id)

    if (updateError) {
      console.error("Failed to update last login:", updateError)
      // Continue anyway, this is not critical
    }

    // Set cookies with proper security settings
    const cookieOptions = {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24, // 1 day
      path: "/",
      sameSite: "lax" as const, // Changed from strict to lax for better cross-site navigation
    }

    // Clear any existing cookies first
    cookies().delete("user_id")
    cookies().delete("role")
    cookies().delete("username")

    // Set new cookies
    cookies().set("user_id", user.id, cookieOptions)
    cookies().set("role", user.role, cookieOptions)
    cookies().set("username", user.username, cookieOptions)

    console.log("Login successful for user:", user.username)
    console.log("Set cookies - role:", user.role)
    console.log("Set cookies - username:", user.username)

    return { success: true, user }
  } catch (err) {
    console.error("Login error:", err)
    return { error: "An error occurred during login" }
  }
}

export async function register(formData: FormData) {
  const username = formData.get("username") as string
  const email = formData.get("email") as string
  const password = formData.get("password") as string
  const confirmPassword = formData.get("confirmPassword") as string

  if (!username || !email || !password) {
    return { error: "All fields are required" }
  }

  if (password !== confirmPassword) {
    return { error: "Passwords do not match" }
  }

  // Validate password strength
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/
  if (!passwordRegex.test(password)) {
    return {
      error: "Password must be at least 8 characters and include uppercase, lowercase, number, and special character",
    }
  }

  try {
    // Check if user already exists
    const { data: existingUser, error: checkError } = await supabaseServer
      .from("users")
      .select("*")
      .or(`email.eq.${email},username.eq.${username}`)
      .single()

    if (existingUser) {
      return { error: "Username or email already exists" }
    }

    if (checkError && checkError.code !== "PGRST116") {
      console.error("Error checking existing user:", checkError)
      return { error: "Failed to check existing user" }
    }

    // Create new user
    const { data: newUser, error } = await supabaseServer
      .from("users")
      .insert([
        {
          username,
          email,
          password, // In a real app, this would be hashed
          role: "user",
          created_at: new Date().toISOString(),
        },
      ])
      .select()
      .single()

    if (error) {
      console.error("Registration error:", error)
      return { error: "Failed to create user" }
    }

    // Set cookies with proper security settings
    const cookieOptions = {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24, // 1 day
      path: "/",
      sameSite: "lax" as const, // Changed from strict to lax for better cross-site navigation
    }

    cookies().set("user_id", newUser.id, cookieOptions)
    cookies().set("role", newUser.role, cookieOptions)
    cookies().set("username", newUser.username, cookieOptions)

    return { success: true, user: newUser }
  } catch (err) {
    console.error("Registration error:", err)
    return { error: "An error occurred during registration" }
  }
}

export async function logout() {
  cookies().delete("user_id")
  cookies().delete("role")
  cookies().delete("username")
  redirect("/login")
}

export async function getCurrentUser(): Promise<User | null> {
  const userId = cookies().get("user_id")?.value

  if (!userId) {
    return null
  }

  try {
    const { data: user, error } = await supabaseServer.from("users").select("*").eq("id", userId).single()

    if (error || !user) {
      console.error("Get current user error:", error)
      return null
    }

    return user as User
  } catch (err) {
    console.error("Get current user error:", err)
    return null
  }
}
