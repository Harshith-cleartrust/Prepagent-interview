"use server"

import { revalidatePath } from "next/cache"
import { supabaseServer } from "@/lib/supabase/server"
import { cookies } from "next/headers"
import type { Test, TestWithQuestions } from "@/lib/types"

export async function createTest(formData: FormData) {
  try {
    // Get the current user ID from cookies
    const userId = cookies().get("user_id")?.value
    const role = cookies().get("role")?.value

    if (!userId) {
      throw new Error("You must be logged in to create a test")
    }

    if (role !== "admin") {
      throw new Error("Only admins can create tests")
    }

    // Extract form data
    const title = formData.get("title") as string
    const description = formData.get("description") as string
    const topic = formData.get("topic") as string
    const duration = Number.parseInt(formData.get("duration") as string, 10)
    const questionsJson = formData.get("questions") as string

    // Validate required fields
    if (!title || !topic || isNaN(duration)) {
      throw new Error("Title, topic, and duration are required")
    }

    // Parse questions
    const questions = JSON.parse(questionsJson)

    console.log("Creating test with data:", {
      title,
      description,
      topic,
      duration,
      userId,
    })

    // Create the test - remove the difficulties field as it doesn't exist in the schema
    const { data: test, error: testError } = await supabaseServer
      .from("tests")
      .insert({
        title,
        description,
        topic,
        duration,
        created_by: userId,
        status: "draft",
      })
      .select()
      .single()

    if (testError) {
      console.error("Error creating test:", testError)
      throw new Error(testError.message || "Failed to create test")
    }

    if (!test) {
      throw new Error("Failed to create test - no test data returned")
    }

    // Insert questions
    const questionsToInsert = questions.map((q) => ({
      test_id: test.id,
      text: q.text,
      options: q.options,
      correct_answer: q.correct_answer,
      explanation: q.explanation,
      difficulty: q.difficulty,
    }))

    const { error: questionsError } = await supabaseServer.from("questions").insert(questionsToInsert)

    if (questionsError) {
      console.error("Error inserting questions:", questionsError)
      throw new Error(questionsError.message || "Failed to insert questions")
    }

    revalidatePath("/admin/tests")
    return { success: true, testId: test.id }
  } catch (error) {
    console.error("Error creating test:", error)
    return { error: error.message || "Failed to create test" }
  }
}

export async function getTests(status?: "active" | "draft" | "completed" | "published"): Promise<Test[]> {
  try {
    const userId = cookies().get("user_id")?.value
    const role = cookies().get("role")?.value

    if (!userId) {
      return []
    }

    let query = supabaseServer.from("tests").select("*").order("created_at", { ascending: false })

    if (role !== "admin") {
      // For non-admin users, show only:
      // 1. Tests they created
      // 2. Published tests
      // 3. Tests specifically assigned to them
      const { data: assignedTestIds, error: assignedError } = await supabaseServer
        .from("user_tests")
        .select("test_id")
        .eq("user_id", userId)

      if (assignedError) {
        console.error("Error fetching assigned tests:", assignedError)
        return []
      }

      const assignedIds = assignedTestIds?.map((item) => item.test_id) || []

      if (assignedIds.length > 0) {
        query = query.or(`created_by.eq.${userId},status.eq.published,id.in.(${assignedIds.join(",")})`)
      } else {
        query = query.or(`created_by.eq.${userId},status.eq.published`)
      }
    }

    if (status) {
      query = query.eq("status", status)
    }

    const { data: tests, error } = await query

    if (error) {
      console.error("Error fetching tests:", error)
      return []
    }

    return tests || []
  } catch (error) {
    console.error("Error fetching tests:", error)
    return []
  }
}

export async function getTest(id: string): Promise<Test | null> {
  try {
    const { data, error } = await supabaseServer.from("tests").select("*").eq("id", id).single()

    if (error) {
      console.error("Error fetching test:", error)
      return null
    }

    return data as Test
  } catch (error) {
    console.error("Error fetching test:", error)
    return null
  }
}

export async function getTestWithQuestions(id: string): Promise<TestWithQuestions | null> {
  try {
    const { data, error } = await supabaseServer.from("tests").select(`*, questions(*)`).eq("id", id).single()

    if (error) {
      console.error("Error fetching test with questions:", error)
      return null
    }

    return data as TestWithQuestions
  } catch (error) {
    console.error("Error fetching test with questions:", error)
    return null
  }
}

export async function updateTestStatus(
  testId: string,
  status: "draft" | "active" | "completed" | "published",
  dueDate?: string,
) {
  try {
    // Update the test status
    const { error } = await supabaseServer.from("tests").update({ status }).eq("id", testId)

    if (error) {
      console.error("Error updating test status:", error)
      return { success: false, error: "Failed to update test status" }
    }

    // If the test is being published, assign it to all users with role "user"
    if (status === "published") {
      // Get all users with role "user"
      const { data: users, error: usersError } = await supabaseServer.from("users").select("id").eq("role", "user")

      if (usersError) {
        console.error("Error fetching users:", usersError)
        return { success: false, error: "Failed to fetch users" }
      }

      if (users && users.length > 0) {
        // Prepare assignments for all users
        const assignments = users.map((user) => ({
          user_id: user.id,
          test_id: testId,
          assigned_at: new Date().toISOString(),
          due_date: dueDate || null,
          status: "assigned",
        }))

        // For each user, check if the test is already assigned
        for (const assignment of assignments) {
          const { data: existingAssignment, error: checkError } = await supabaseServer
            .from("user_tests")
            .select("id")
            .eq("user_id", assignment.user_id)
            .eq("test_id", testId)

          if (checkError) {
            console.error("Error checking existing assignment:", checkError)
            continue
          }

          // If the test is not already assigned to this user, assign it
          if (!existingAssignment || existingAssignment.length === 0) {
            const { error: assignError } = await supabaseServer.from("user_tests").insert([assignment])

            if (assignError) {
              console.error("Error assigning test to user:", assignError)
            }
          }
        }
      }
    }

    revalidatePath("/admin/tests")
    revalidatePath("/user/active-tests")
    return { success: true }
  } catch (error) {
    console.error("Error updating test status:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

export async function publishTest(testId: string, dueDate?: string) {
  return updateTestStatus(testId, "published", dueDate)
}

export async function deleteTest(testId: string) {
  try {
    // Delete associated questions first
    const { error: questionsError } = await supabaseServer.from("questions").delete().eq("test_id", testId)

    if (questionsError) {
      console.error("Error deleting questions:", questionsError)
      return { success: false, error: "Failed to delete associated questions" }
    }

    const { error } = await supabaseServer.from("tests").delete().eq("id", testId)

    if (error) {
      console.error("Error deleting test:", error)
      return { success: false, error: "Failed to delete test" }
    }

    revalidatePath("/admin/tests")
    return { success: true }
  } catch (error) {
    console.error("Error deleting test:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

export async function assignTestToUser(testId: string, userId: string, dueDate?: string) {
  try {
    // Check if the test is already assigned to the user
    const { data: existingAssignment, error: existingAssignmentError } = await supabaseServer
      .from("user_tests")
      .select("*")
      .eq("user_id", userId)
      .eq("test_id", testId)

    if (existingAssignmentError) {
      console.error("Error checking existing assignment:", existingAssignmentError)
      return { success: false, error: "Failed to check existing assignment" }
    }

    // If there are any existing assignments, don't create a new one
    if (existingAssignment && existingAssignment.length > 0) {
      return { success: false, error: "Test is already assigned to this user" }
    }

    // Get the test to check its status
    const { data: test, error: testError } = await supabaseServer
      .from("tests")
      .select("status")
      .eq("id", testId)
      .single()

    if (testError) {
      console.error("Error fetching test:", testError)
      return { success: false, error: "Failed to fetch test information" }
    }

    // Insert the assignment
    const { error } = await supabaseServer.from("user_tests").insert([
      {
        user_id: userId,
        test_id: testId,
        assigned_at: new Date().toISOString(),
        due_date: dueDate || null,
        status: "assigned",
      },
    ])

    if (error) {
      console.error("Error assigning test to user:", error)
      return { success: false, error: "Failed to assign test to user" }
    }

    revalidatePath("/admin/users")
    revalidatePath("/user/active-tests")
    revalidatePath("/user/dashboard")
    return { success: true }
  } catch (error) {
    console.error("Error assigning test to user:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}
