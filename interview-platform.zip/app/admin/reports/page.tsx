"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { FileText, Download, Calendar, User, BarChart3, CheckCircle, Lightbulb } from "lucide-react"
import { analyzeTestResults, analyzeUserPerformance } from "@/lib/analytics-service"
import { supabase } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"
import dynamic from "next/dynamic"

// Dynamically import jsPDF with no SSR
const JsPDF = dynamic(() => import("jspdf"), { ssr: false })

export default function ReportsPage() {
  const [reportType, setReportType] = useState("performance")
  const [period, setPeriod] = useState("last6months")
  const [selectedUser, setSelectedUser] = useState("")
  const [selectedTest, setSelectedTest] = useState("")
  const [reportTitle, setReportTitle] = useState("")
  const [reportDescription, setReportDescription] = useState("")
  const [users, setUsers] = useState([])
  const [tests, setTests] = useState([])
  const [loading, setLoading] = useState(false)
  const [generating, setGenerating] = useState(false)
  const [reportData, setReportData] = useState(null)
  const [aiInsights, setAiInsights] = useState("")
  const [downloadingPdf, setDownloadingPdf] = useState(false)
  const { toast } = useToast()

  // Fetch users and tests on page load
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        // Fetch users
        const { data: usersData, error: usersError } = await supabase
          .from("users")
          .select("id, username")
          .eq("role", "user")

        if (usersError) {
          console.error("Error fetching users:", usersError)
        } else {
          setUsers(usersData || [])
        }

        // Fetch tests
        const { data: testsData, error: testsError } = await supabase.from("tests").select("id, title")

        if (testsError) {
          console.error("Error fetching tests:", testsError)
        } else {
          setTests(testsData || [])
        }
      } catch (error) {
        console.error("Error fetching data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  // Generate report based on selected options
  const generateReport = async () => {
    setGenerating(true)
    try {
      let data = {}
      let insights = ""

      if (reportType === "performance") {
        // Fetch performance data for the selected user
        const { data: results, error } = await supabase
          .from("test_results")
          .select(`
            id, 
            score, 
            completed_at,
            tests (
              id,
              title,
              topic
            )
          `)
          .eq("user_id", selectedUser)

        if (error) {
          console.error("Error fetching results:", error)
          return
        }

        // Get user details
        const { data: userData, error: userError } = await supabase
          .from("users")
          .select("username, email")
          .eq("id", selectedUser)
          .single()

        if (userError) {
          console.error("Error fetching user:", userError)
          return
        }

        // Process topic performance
        const topicScores = {}
        results.forEach((result) => {
          const topic = result.tests?.topic || "Unknown"

          if (!topicScores[topic]) {
            topicScores[topic] = { scores: [], count: 0 }
          }

          topicScores[topic].scores.push(result.score)
          topicScores[topic].count++
        })

        const topicPerformance = Object.entries(topicScores)
          .map(([topic, data]) => ({
            topic,
            score: Math.round(data.scores.reduce((sum, score) => sum + score, 0) / data.scores.length),
            tests: data.count,
          }))
          .sort((a, b) => b.score - a.score)

        // Calculate average score
        const averageScore =
          results.length > 0 ? Math.round(results.reduce((sum, result) => sum + result.score, 0) / results.length) : 0

        // Generate AI insights
        insights = await analyzeUserPerformance({
          results,
          topicPerformance,
          userData,
        })

        data = {
          type: "User Performance Report",
          user: userData,
          results: results.map((r) => ({
            ...r,
            completed_at: new Date(r.completed_at).toLocaleDateString(),
            test_title: r.tests?.title || "Unknown Test",
          })),
          topicPerformance,
          averageScore,
          totalTests: results.length,
          reportDate: new Date().toLocaleDateString(),
          reportTitle: reportTitle || `Performance Report for ${userData.username}`,
          reportDescription: reportDescription || `Comprehensive analysis of test performance for ${userData.username}`,
        }
      } else if (reportType === "test") {
        // Fetch results for the selected test
        const { data: results, error } = await supabase
          .from("test_results")
          .select(`
            id, 
            score, 
            completed_at,
            users (
              id,
              username
            )
          `)
          .eq("test_id", selectedTest)

        if (error) {
          console.error("Error fetching results:", error)
          return
        }

        // Get test details
        const { data: testData, error: testError } = await supabase
          .from("tests")
          .select("title, topic, description")
          .eq("id", selectedTest)
          .single()

        if (testError) {
          console.error("Error fetching test:", testError)
          return
        }

        // Calculate average score
        const averageScore =
          results.length > 0 ? Math.round(results.reduce((sum, result) => sum + result.score, 0) / results.length) : 0

        // Generate AI insights
        insights = await analyzeTestResults({
          results,
          testData,
          averageScore,
          participantCount: results.length,
        })

        data = {
          type: "Test Analysis Report",
          test: testData,
          results: results.map((r) => ({
            ...r,
            completed_at: new Date(r.completed_at).toLocaleDateString(),
            username: r.users?.username || "Unknown User",
          })),
          averageScore,
          participantCount: results.length,
          reportDate: new Date().toLocaleDateString(),
          reportTitle: reportTitle || `Analysis Report for ${testData.title}`,
          reportDescription: reportDescription || `Comprehensive analysis of results for ${testData.title}`,
        }
      }

      setReportData(data)
      setAiInsights(insights)
    } catch (error) {
      console.error("Error generating report:", error)
    } finally {
      setGenerating(false)
    }
  }

  // Generate and download PDF
  const downloadPdf = async () => {
    setDownloadingPdf(true)
    try {
      // Import jsPDF
      const jsPDF = await import("jspdf")

      // Create new jsPDF instance
      const doc = new jsPDF.default({
        orientation: "portrait",
        unit: "mm",
        format: "a4",
      })

      // Define colors and styles
      const primaryColor = [102, 51, 153] // Purple in RGB
      const textColor = [60, 60, 60] // Dark gray
      const lightGray = [200, 200, 200] // Light gray for lines

      // Add header with logo and title
      doc.setFillColor(245, 245, 250) // Light purple background
      doc.rect(0, 0, 210, 30, "F")

      // Add title
      doc.setFontSize(20)
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2])
      doc.text("SAMAJH AI-Powered Interview Platform", 105, 15, { align: "center" })

      // Add report title
      doc.setFontSize(16)
      doc.setTextColor(textColor[0], textColor[1], textColor[2])
      doc.text(reportData.reportTitle, 105, 40, { align: "center" })

      // Add report description
      doc.setFontSize(10)
      doc.text(reportData.reportDescription, 105, 48, { align: "center", maxWidth: 150 })

      // Add date
      doc.setFontSize(10)
      doc.setTextColor(100, 100, 100)
      doc.text(`Generated on: ${reportData.reportDate}`, 105, 55, { align: "center" })

      // Add horizontal line
      doc.setDrawColor(lightGray[0], lightGray[1], lightGray[2])
      doc.line(20, 60, 190, 60)

      // Add report summary section
      doc.setFontSize(14)
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2])
      doc.text("Report Summary", 20, 70)

      // Add summary boxes
      doc.setFillColor(250, 250, 255)
      doc.roundedRect(20, 75, 50, 25, 2, 2, "F")
      doc.roundedRect(80, 75, 50, 25, 2, 2, "F")
      doc.roundedRect(140, 75, 50, 25, 2, 2, "F")

      // Add summary content
      doc.setFontSize(10)
      doc.setTextColor(100, 100, 100)

      // Box 1
      doc.text("Report Type", 45, 82, { align: "center" })
      doc.setTextColor(textColor[0], textColor[1], textColor[2])
      doc.text(reportData.type, 45, 90, { align: "center" })

      // Box 2
      doc.setTextColor(100, 100, 100)
      doc.text(reportData.type === "User Performance Report" ? "Tests Completed" : "Participants", 105, 82, {
        align: "center",
      })
      doc.setTextColor(textColor[0], textColor[1], textColor[2])
      doc.text(
        reportData.type === "User Performance Report"
          ? reportData.totalTests.toString()
          : reportData.participantCount.toString(),
        105,
        90,
        { align: "center" },
      )

      // Box 3
      doc.setTextColor(100, 100, 100)
      doc.text("Average Score", 165, 82, { align: "center" })
      doc.setTextColor(textColor[0], textColor[1], textColor[2])
      doc.text(`${reportData.averageScore}%`, 165, 90, { align: "center" })

      // Add subject information section
      doc.setFontSize(14)
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2])
      doc.text(reportData.type === "User Performance Report" ? "User Information" : "Test Information", 20, 115)

      // Add subject information content
      doc.setFillColor(250, 250, 255)
      doc.roundedRect(20, 120, 170, 35, 2, 2, "F")

      doc.setFontSize(10)

      if (reportData.type === "User Performance Report") {
        // User information
        doc.setTextColor(100, 100, 100)
        doc.text("Name:", 30, 130)
        doc.text("Email:", 30, 138)
        doc.text("Tests Completed:", 30, 146)
        doc.text("Average Score:", 30, 154)

        doc.setTextColor(textColor[0], textColor[1], textColor[2])
        doc.text(reportData.user.username, 70, 130)
        doc.text(reportData.user.email, 70, 138)
        doc.text(reportData.totalTests.toString(), 70, 146)
        doc.text(`${reportData.averageScore}%`, 70, 154)
      } else {
        // Test information
        doc.setTextColor(100, 100, 100)
        doc.text("Test Title:", 30, 130)
        doc.text("Topic:", 30, 138)
        doc.text("Participants:", 30, 146)
        doc.text("Average Score:", 30, 154)

        doc.setTextColor(textColor[0], textColor[1], textColor[2])
        doc.text(reportData.test.title, 70, 130)
        doc.text(reportData.test.topic, 70, 138)
        doc.text(reportData.participantCount.toString(), 70, 146)
        doc.text(`${reportData.averageScore}%`, 70, 154)
      }

      // Add topic performance section for user reports
      let currentY = 165

      if (reportData.type === "User Performance Report" && reportData.topicPerformance) {
        doc.setFontSize(14)
        doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2])
        doc.text("Topic Performance", 20, currentY)
        currentY += 10

        // Manually create a table for topic performance
        doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2])
        doc.rect(20, currentY, 170, 8, "F")

        // Table headers
        doc.setTextColor(255, 255, 255)
        doc.setFontSize(10)
        doc.text("Topic", 25, currentY + 5)
        doc.text("Score", 120, currentY + 5)
        doc.text("Tests", 150, currentY + 5)

        currentY += 8

        // Table rows
        doc.setTextColor(textColor[0], textColor[1], textColor[2])
        reportData.topicPerformance.forEach((topic, index) => {
          // Alternate row background
          if (index % 2 === 0) {
            doc.setFillColor(245, 245, 250)
            doc.rect(20, currentY, 170, 8, "F")
          }

          // Ensure topic text doesn't overflow
          const topicText = doc.splitTextToSize(topic.topic, 90)
          doc.text(topicText, 25, currentY + 5)
          doc.text(`${topic.score}%`, 120, currentY + 5)
          doc.text(`${topic.tests}`, 150, currentY + 5)

          // Adjust row height based on text wrapping
          const rowHeight = Math.max(8, topicText.length * 5)
          currentY += rowHeight
        })

        currentY += 10
      }

      // Check if we need a new page
      if (currentY > 240) {
        doc.addPage()
        currentY = 20
      }

      // Add results section
      doc.setFontSize(14)
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2])
      doc.text(reportData.type === "User Performance Report" ? "Test Results" : "Participant Results", 20, currentY)
      currentY += 10

      // Manually create a table for results
      doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2])
      doc.rect(20, currentY, 170, 8, "F")

      // Table headers
      doc.setTextColor(255, 255, 255)
      doc.setFontSize(10)
      doc.text(reportData.type === "User Performance Report" ? "Test" : "User", 25, currentY + 5)
      doc.text("Score", 120, currentY + 5)
      doc.text("Date", 150, currentY + 5)

      currentY += 8

      // Table rows
      doc.setTextColor(textColor[0], textColor[1], textColor[2])
      reportData.results.forEach((result, index) => {
        // Check if we need a new page
        if (currentY > 270) {
          doc.addPage()
          currentY = 20

          // Add table header on new page
          doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2])
          doc.rect(20, currentY, 170, 8, "F")

          doc.setTextColor(255, 255, 255)
          doc.text(reportData.type === "User Performance Report" ? "Test" : "User", 25, currentY + 5)
          doc.text("Score", 120, currentY + 5)
          doc.text("Date", 150, currentY + 5)

          currentY += 8
          doc.setTextColor(textColor[0], textColor[1], textColor[2])
        }

        // Alternate row background
        if (index % 2 === 0) {
          doc.setFillColor(245, 245, 250)
          doc.rect(20, currentY, 170, 8, "F")
        }

        // Ensure test/user name doesn't overflow
        const nameText = reportData.type === "User Performance Report" ? result.test_title : result.username
        const wrappedName = doc.splitTextToSize(nameText, 90)
        doc.text(wrappedName, 25, currentY + 5)
        doc.text(`${result.score}%`, 120, currentY + 5)
        doc.text(result.completed_at, 150, currentY + 5)

        // Adjust row height based on text wrapping
        const rowHeight = Math.max(8, wrappedName.length * 5)
        currentY += rowHeight
      })

      currentY += 15

      // Check if we need a new page for AI insights
      if (currentY > 220) {
        doc.addPage()
        currentY = 20
      }

      // Add AI insights section
      doc.setFontSize(14)
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2])
      doc.text("AI-Generated Insights", 20, currentY)
      currentY += 10

      // Add AI insights content
      if (aiInsights) {
        // First, check if there's an introduction paragraph before the numbered points
        let introduction = ""
        let numberedInsights = aiInsights

        // Extract introduction if it exists (text before the first numbered point)
        const introMatch = aiInsights.match(/^(.*?)(?=\d+\.\s+|$)/s)
        if (introMatch && introMatch[1].trim()) {
          introduction = introMatch[1].trim()
          numberedInsights = aiInsights.substring(introMatch[0].length)
        }

        // Process the numbered insights
        const insights = numberedInsights
          .split(/\d+\.\s+/)
          .filter(Boolean)
          .map((insight) => {
            const parts = insight.split(":")
            return {
              title: parts[0].trim(),
              content: parts.slice(1).join(":").trim(),
            }
          })

        // Create a larger container for insights
        doc.setFillColor(250, 250, 255)
        // Calculate height based on content
        const estimatedHeight = Math.min(240, (introduction ? 40 : 0) + insights.length * 40)
        doc.roundedRect(20, currentY, 170, estimatedHeight, 2, 2, "F")

        let insightY = currentY + 10

        // Add introduction if it exists
        if (introduction) {
          doc.setFontSize(10)
          doc.setTextColor(textColor[0], textColor[1], textColor[2])

          // Wrap the introduction text
          const splitIntro = doc.splitTextToSize(introduction, 160)
          doc.text(splitIntro, 25, insightY)

          // Move down based on the number of lines in the introduction
          insightY += splitIntro.length * 5 + 10

          // Add a small separator
          doc.setDrawColor(lightGray[0], lightGray[1], lightGray[2])
          doc.line(25, insightY - 5, 185, insightY - 5)
        }

        // Process each insight
        insights.forEach((insight, index) => {
          // Check if we need a new page
          if (insightY > 250) {
            doc.addPage()
            insightY = 20

            // Add a background for the continued insights
            doc.setFillColor(250, 250, 255)
            doc.roundedRect(20, insightY - 10, 170, 240, 2, 2, "F")
          }

          // Add the insight title with more emphasis
          doc.setFontSize(11)
          doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2])

          // Wrap the title in case it's long
          const splitTitle = doc.splitTextToSize(insight.title, 160)
          doc.text(splitTitle, 25, insightY)

          // Move down based on title length
          insightY += splitTitle.length * 5 + 5

          // Add the insight content with proper wrapping
          doc.setFontSize(10)
          doc.setTextColor(textColor[0], textColor[1], textColor[2])
          const splitContent = doc.splitTextToSize(insight.content, 160)
          doc.text(splitContent, 25, insightY)

          // Calculate space needed for this content and add more padding
          insightY += splitContent.length * 5 + 15
        })
      } else {
        doc.setFontSize(10)
        doc.setTextColor(100, 100, 100)
        doc.text("No AI insights available for this report.", 20, currentY + 10)
      }

      // Add footer
      const pageCount = doc.getNumberOfPages()

      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i)

        // Footer background
        doc.setFillColor(245, 245, 250)
        doc.rect(0, 280, 210, 17, "F")

        // Footer text
        doc.setFontSize(8)
        doc.setTextColor(100, 100, 100)
        doc.text("Generated by SAMAJH AI-Powered Interview Platform", 105, 287, { align: "center" })
        doc.text(`Page ${i} of ${pageCount}`, 185, 287)
      }

      // Save the PDF
      const filename = `${reportData.reportTitle.replace(/\s+/g, "_")}.pdf`
      doc.save(filename)

      toast({
        title: "PDF generated successfully",
        description: "Your report has been downloaded.",
      })
    } catch (error) {
      console.error("Error generating PDF:", error)
      toast({
        title: "PDF generation failed",
        description: "There was an error generating the PDF. Please try again.",
        variant: "destructive",
      })
    } finally {
      setDownloadingPdf(false)
    }
  }

  return (
    <DashboardLayout requiredRole="admin">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-purple-800">Reports</h1>

        {!reportData ? (
          <Card className="border-purple-200">
            <CardHeader>
              <CardTitle className="text-xl text-purple-800">Generate Report</CardTitle>
              <CardDescription>Create detailed reports with AI-powered insights</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="reportType">Report Type</Label>
                <Select value={reportType} onValueChange={setReportType}>
                  <SelectTrigger className="border-purple-200 focus:border-purple-500">
                    <SelectValue placeholder="Select report type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="performance">User Performance Report</SelectItem>
                    <SelectItem value="test">Test Analysis Report</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {reportType === "performance" && (
                <div className="space-y-2">
                  <Label htmlFor="user">Select User</Label>
                  <Select value={selectedUser} onValueChange={setSelectedUser}>
                    <SelectTrigger className="border-purple-200 focus:border-purple-500">
                      <SelectValue placeholder="Select user" />
                    </SelectTrigger>
                    <SelectContent>
                      {users.map((user) => (
                        <SelectItem key={user.id} value={user.id}>
                          {user.username}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {reportType === "test" && (
                <div className="space-y-2">
                  <Label htmlFor="test">Select Test</Label>
                  <Select value={selectedTest} onValueChange={setSelectedTest}>
                    <SelectTrigger className="border-purple-200 focus:border-purple-500">
                      <SelectValue placeholder="Select test" />
                    </SelectTrigger>
                    <SelectContent>
                      {tests.map((test) => (
                        <SelectItem key={test.id} value={test.id}>
                          {test.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="period">Time Period</Label>
                <Select value={period} onValueChange={setPeriod}>
                  <SelectTrigger className="border-purple-200 focus:border-purple-500">
                    <SelectValue placeholder="Select period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="last30days">Last 30 days</SelectItem>
                    <SelectItem value="last3months">Last 3 months</SelectItem>
                    <SelectItem value="last6months">Last 6 months</SelectItem>
                    <SelectItem value="lastyear">Last year</SelectItem>
                    <SelectItem value="alltime">All time</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="reportTitle">Report Title (Optional)</Label>
                <Input
                  id="reportTitle"
                  value={reportTitle}
                  onChange={(e) => setReportTitle(e.target.value)}
                  placeholder={
                    reportType === "performance" ? "Performance Report for [User]" : "Analysis Report for [Test]"
                  }
                  className="border-purple-200 focus:border-purple-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="reportDescription">Report Description (Optional)</Label>
                <Textarea
                  id="reportDescription"
                  value={reportDescription}
                  onChange={(e) => setReportDescription(e.target.value)}
                  placeholder="Enter a description for this report"
                  className="border-purple-200 focus:border-purple-500"
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button
                onClick={generateReport}
                disabled={
                  generating ||
                  (reportType === "performance" && !selectedUser) ||
                  (reportType === "test" && !selectedTest)
                }
                className="ml-auto bg-purple-700 hover:bg-purple-800 text-white"
              >
                {generating ? (
                  <>
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                    Generating Report...
                  </>
                ) : (
                  <>
                    <FileText className="mr-2 h-4 w-4" />
                    Generate Report
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        ) : (
          <div className="space-y-6">
            {/* PDF-style Report */}
            <div className="bg-white border border-gray-200 rounded-md shadow-lg max-w-4xl mx-auto">
              {/* Report Header */}
              <div className="p-8 border-b border-gray-200">
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-2xl font-bold text-purple-800">{reportData.reportTitle}</h2>
                    <p className="text-gray-500 mt-1">{reportData.reportDescription}</p>
                  </div>
                  <div className="flex items-center gap-2 text-gray-500">
                    <Calendar className="h-4 w-4" />
                    <span>{reportData.reportDate}</span>
                  </div>
                </div>
              </div>

              {/* Report Content */}
              <div className="p-8">
                {/* Report Summary */}
                <div className="mb-8">
                  <h3 className="text-lg font-semibold text-purple-800 mb-4">Report Summary</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card className="border-purple-100">
                      <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                        {reportData.type === "User Performance Report" ? (
                          <User className="h-8 w-8 text-purple-600 mb-2" />
                        ) : (
                          <FileText className="h-8 w-8 text-purple-600 mb-2" />
                        )}
                        <p className="text-sm text-gray-500">Report Type</p>
                        <p className="font-medium">{reportData.type}</p>
                      </CardContent>
                    </Card>

                    <Card className="border-purple-100">
                      <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                        {reportData.type === "User Performance Report" ? (
                          <CheckCircle className="h-8 w-8 text-purple-600 mb-2" />
                        ) : (
                          <User className="h-8 w-8 text-purple-600 mb-2" />
                        )}
                        <p className="text-sm text-gray-500">
                          {reportData.type === "User Performance Report" ? "Tests Completed" : "Participants"}
                        </p>
                        <p className="font-medium">
                          {reportData.type === "User Performance Report"
                            ? reportData.totalTests
                            : reportData.participantCount}
                        </p>
                      </CardContent>
                    </Card>

                    <Card className="border-purple-100">
                      <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                        <BarChart3 className="h-8 w-8 text-purple-600 mb-2" />
                        <p className="text-sm text-gray-500">Average Score</p>
                        <p className="font-medium">{reportData.averageScore}%</p>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                {/* Subject Information */}
                <div className="mb-8">
                  <h3 className="text-lg font-semibold text-purple-800 mb-4">
                    {reportData.type === "User Performance Report" ? "User Information" : "Test Information"}
                  </h3>
                  <Card className="border-purple-100">
                    <CardContent className="p-4">
                      {reportData.type === "User Performance Report" ? (
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-500">Name:</span>
                            <span className="font-medium">{reportData.user.username}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Email:</span>
                            <span className="font-medium">{reportData.user.email}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Tests Completed:</span>
                            <span className="font-medium">{reportData.totalTests}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Average Score:</span>
                            <span className="font-medium">{reportData.averageScore}%</span>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-500">Test Title:</span>
                            <span className="font-medium">{reportData.test.title}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Topic:</span>
                            <span className="font-medium">{reportData.test.topic}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Participants:</span>
                            <span className="font-medium">{reportData.participantCount}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Average Score:</span>
                            <span className="font-medium">{reportData.averageScore}%</span>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>

                {/* Performance Data */}
                {reportData.type === "User Performance Report" && reportData.topicPerformance && (
                  <div className="mb-8">
                    <h3 className="text-lg font-semibold text-purple-800 mb-4">Topic Performance</h3>
                    <Card className="border-purple-100">
                      <CardContent className="p-4">
                        <div className="space-y-4">
                          {reportData.topicPerformance.map((topic, index) => (
                            <div key={index} className="space-y-1">
                              <div className="flex justify-between">
                                <span className="font-medium">{topic.topic}</span>
                                <span className="text-sm">{topic.score}%</span>
                              </div>
                              <div className="h-2 w-full bg-purple-100 rounded-full">
                                <div
                                  className="h-2 bg-purple-600 rounded-full"
                                  style={{ width: `${topic.score}%` }}
                                ></div>
                              </div>
                              <div className="text-xs text-gray-500 text-right">{topic.tests} tests</div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}

                {/* Test Results */}
                <div className="mb-8">
                  <h3 className="text-lg font-semibold text-purple-800 mb-4">
                    {reportData.type === "User Performance Report" ? "Test Results" : "Participant Results"}
                  </h3>
                  <Card className="border-purple-100">
                    <CardContent className="p-4">
                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead>
                            <tr className="border-b border-purple-100">
                              <th className="text-left py-2 px-2 text-purple-800">
                                {reportData.type === "User Performance Report" ? "Test" : "User"}
                              </th>
                              <th className="text-center py-2 px-2 text-purple-800">Score</th>
                              <th className="text-right py-2 px-2 text-purple-800">Date</th>
                            </tr>
                          </thead>
                          <tbody>
                            {reportData.results.map((result, index) => (
                              <tr key={index} className="border-b border-purple-50 last:border-0">
                                <td className="py-2 px-2">
                                  {reportData.type === "User Performance Report" ? result.test_title : result.username}
                                </td>
                                <td className="py-2 px-2 text-center">
                                  <span
                                    className={`px-2 py-1 rounded-full text-xs ${
                                      result.score >= 80
                                        ? "bg-green-100 text-green-800"
                                        : result.score >= 60
                                          ? "bg-yellow-100 text-yellow-800"
                                          : "bg-red-100 text-red-800"
                                    }`}
                                  >
                                    {result.score}%
                                  </span>
                                </td>
                                <td className="py-2 px-2 text-right text-gray-500">{result.completed_at}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* AI Insights */}
                <div className="mb-8">
                  <div className="flex items-center gap-2 mb-4">
                    <Lightbulb className="h-5 w-5 text-purple-800" />
                    <h3 className="text-lg font-semibold text-purple-800">AI-Generated Insights</h3>
                  </div>
                  <Card className="border-purple-100">
                    <CardContent className="p-6">
                      <div className="prose max-w-none">
                        {aiInsights ? (
                          <div className="space-y-4">
                            {aiInsights
                              .split(/\d+\.\s+/)
                              .filter(Boolean)
                              .map((insight, index) => (
                                <div key={index} className="text-gray-700">
                                  <p className="text-lg font-medium text-purple-800 mb-2">
                                    {insight.split(":")[0].trim()}
                                  </p>
                                  <p className="text-base">{insight.split(":").slice(1).join(":").trim()}</p>
                                </div>
                              ))}
                          </div>
                        ) : (
                          <p className="text-gray-500 italic">No AI insights available for this report.</p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Report Footer */}
              <div className="p-8 border-t border-gray-200 flex justify-between items-center">
                <p className="text-sm text-gray-500">Generated by SAMAJH AI-Powered Interview Platform</p>
                <div id="download-button-container">
                  <Button
                    onClick={downloadPdf}
                    variant="outline"
                    className="border-purple-200 text-purple-700"
                    disabled={downloadingPdf}
                  >
                    {downloadingPdf ? (
                      <>
                        <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-purple-700 border-t-transparent"></div>
                        Generating PDF...
                      </>
                    ) : (
                      <>
                        <Download className="mr-2 h-4 w-4" />
                        Download PDF
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-4">
              <Button
                variant="outline"
                className="border-purple-200 text-purple-700"
                onClick={() => setReportData(null)}
              >
                Generate Another Report
              </Button>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
