"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ClipboardList, Download, Mail, MoreHorizontal, Search, User2, UserPlus } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { assignTestToUser } from "@/app/actions/tests"
import { getTests } from "@/app/actions/tests"
import { useRouter } from "next/navigation"
import { supabase } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"
import type { User, Test } from "@/lib/types"
import dynamic from "next/dynamic"

// Dynamically import jsPDF with no SSR
const JsPDF = dynamic(() => import("jspdf"), { ssr: false })

export default function UserManagement() {
  const router = useRouter()
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [assignDialogOpen, setAssignDialogOpen] = useState(false)
  const [selectedUser, setSelectedUser] = useState<string | null>(null)
  const [selectedTest, setSelectedTest] = useState<string>("")
  const [dueDate, setDueDate] = useState<string>("")
  const [notes, setNotes] = useState<string>("")
  const [users, setUsers] = useState<User[]>([])
  const [tests, setTests] = useState<Test[]>([])
  const [loading, setLoading] = useState(true)
  const [testStatus, setTestStatus] = useState<"active" | "draft" | "all">("active")
  const [viewProfileDialogOpen, setViewProfileDialogOpen] = useState(false)
  const [profileUser, setProfileUser] = useState<User | null>(null)
  const [userTestResults, setUserTestResults] = useState<any[]>([])
  const [downloadingPdf, setDownloadingPdf] = useState(false)

  // First, update the state variables at the top of the component to include new user dialog state
  const [addUserDialogOpen, setAddUserDialogOpen] = useState(false)
  const [newUser, setNewUser] = useState({
    username: "",
    email: "",
    password: "",
    role: "user",
  })
  const [formErrors, setFormErrors] = useState<{
    username?: string
    email?: string
    password?: string
  }>({})

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch users
        const response = await fetch("/api/users")
        if (!response.ok) {
          throw new Error("Failed to fetch users")
        }
        const userData = await response.json()

        // Filter out admin users
        const filteredUsers = userData.users.filter((user: User) => user.role !== "admin")
        setUsers(filteredUsers)

        // Fetch tests based on selected status
        fetchTests()
      } catch (error) {
        console.error("Error fetching data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  const fetchTests = async (status: "active" | "draft" | "all" = testStatus) => {
    try {
      // If "all" is selected, fetch both active and draft tests
      if (status === "all") {
        const activeTests = await getTests("active")
        const draftTests = await getTests("draft")
        setTests([...activeTests, ...draftTests])
      } else {
        const testsData = await getTests(status)
        setTests(testsData)
      }
    } catch (error) {
      console.error("Error fetching tests:", error)
    }
  }

  const handleTestStatusChange = (status: "active" | "draft" | "all") => {
    setTestStatus(status)
    fetchTests(status)
  }

  const filteredUsers = users.filter(
    (user) =>
      user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleAssignTest = (userId: string) => {
    setSelectedUser(userId)
    setSelectedTest("")
    setDueDate("")
    setNotes("")
    setAssignDialogOpen(true)
  }

  const handleAssignSubmit = async () => {
    if (!selectedUser || !selectedTest) {
      return
    }

    try {
      const result = await assignTestToUser(selectedTest, selectedUser, dueDate || undefined)

      if (result.success) {
        // Close the dialog
        setAssignDialogOpen(false)

        toast({
          title: "Success",
          description: "Test assigned successfully!",
        })
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to assign test",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error assigning test:", error)
      toast({
        title: "Error",
        description: "An error occurred while assigning the test",
        variant: "destructive",
      })
    }
  }

  // Add a function to handle adding a new user
  const handleAddUser = async () => {
    // Reset errors
    setFormErrors({})

    // Validate form
    const errors: {
      username?: string
      email?: string
      password?: string
    } = {}

    if (!newUser.username.trim()) {
      errors.username = "Username is required"
    }

    if (!newUser.email.trim()) {
      errors.email = "Email is required"
    } else if (!/\S+@\S+\.\S+/.test(newUser.email)) {
      errors.email = "Email is invalid"
    }

    if (!newUser.password.trim()) {
      errors.password = "Password is required"
    } else if (newUser.password.length < 6) {
      errors.password = "Password must be at least 6 characters"
    }

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors)
      return
    }

    try {
      // Add user to database
      const response = await fetch("/api/users", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newUser),
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || "Failed to add user")
      }

      const data = await response.json()

      // Add the new user to the state
      setUsers([data.user, ...users])

      // Reset form and close dialog
      setNewUser({
        username: "",
        email: "",
        password: "",
        role: "user",
      })
      setAddUserDialogOpen(false)

      toast({
        title: "Success",
        description: "User added successfully!",
      })
    } catch (error) {
      console.error("Error adding user:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "An error occurred while adding the user",
        variant: "destructive",
      })
    }
  }

  // Function to handle viewing a user's profile
  const handleViewProfile = async (userId: string) => {
    try {
      setLoading(true)

      // Fetch user details
      const { data: userData, error: userError } = await supabase.from("users").select("*").eq("id", userId).single()

      if (userError) {
        throw new Error("Failed to fetch user details")
      }

      // Fetch user's test results
      const { data: testResults, error: testError } = await supabase
        .from("test_results")
        .select(`
          id,
          score,
          completed_at,
          tests (
            id,
            title,
            topic
          )
        `)
        .eq("user_id", userId)
        .order("completed_at", { ascending: false })

      if (testError) {
        throw new Error("Failed to fetch test results")
      }

      setProfileUser(userData)
      setUserTestResults(testResults || [])
      setViewProfileDialogOpen(true)
    } catch (error) {
      console.error("Error fetching user profile:", error)
      toast({
        title: "Error",
        description: "Failed to load user profile",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Function to download user report
  const handleDownloadReport = async (userId: string) => {
    try {
      setDownloadingPdf(true)

      // Fetch user details
      const { data: userData, error: userError } = await supabase.from("users").select("*").eq("id", userId).single()

      if (userError) {
        throw new Error("Failed to fetch user details")
      }

      // Fetch user's test results
      const { data: testResults, error: testError } = await supabase
        .from("test_results")
        .select(`
          id,
          score,
          completed_at,
          tests (
            id,
            title,
            topic
          )
        `)
        .eq("user_id", userId)
        .order("completed_at", { ascending: false })

      if (testError) {
        throw new Error("Failed to fetch test results")
      }

      // Process topic performance
      const topicScores: Record<string, { scores: number[]; count: number }> = {}
      testResults?.forEach((result) => {
        const topic = result.tests?.topic || "Unknown"

        if (!topicScores[topic]) {
          topicScores[topic] = { scores: [], count: 0 }
        }

        topicScores[topic].scores.push(result.score)
        topicScores[topic].count++
      })

      const topicPerformance = Object.entries(topicScores)
        .map(([topic, data]) => ({
          topic,
          score: Math.round(data.scores.reduce((sum, score) => sum + score, 0) / data.scores.length),
          tests: data.count,
        }))
        .sort((a, b) => b.score - a.score)

      // Calculate average score
      const averageScore =
        testResults && testResults.length > 0
          ? Math.round(testResults.reduce((sum, result) => sum + result.score, 0) / testResults.length)
          : 0

      // Generate PDF
      const jsPDF = await import("jspdf")

      // Create new jsPDF instance
      const doc = new jsPDF.default({
        orientation: "portrait",
        unit: "mm",
        format: "a4",
      })

      // Define colors and styles
      const primaryColor = [102, 51, 153] // Purple in RGB
      const textColor = [60, 60, 60] // Dark gray
      const lightGray = [200, 200, 200] // Light gray for lines

      // Add header with logo and title
      doc.setFillColor(245, 245, 250) // Light purple background
      doc.rect(0, 0, 210, 30, "F")

      // Add title
      doc.setFontSize(20)
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2])
      doc.text("SAMAJH AI-Powered Interview Platform", 105, 15, { align: "center" })

      // Add report title
      doc.setFontSize(16)
      doc.setTextColor(textColor[0], textColor[1], textColor[2])
      doc.text(`User Report: ${userData.username}`, 105, 40, { align: "center" })

      // Add report description
      doc.setFontSize(10)
      doc.text(`Performance summary for ${userData.username}`, 105, 48, { align: "center", maxWidth: 150 })

      // Add date
      doc.setFontSize(10)
      doc.setTextColor(100, 100, 100)
      doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 105, 55, { align: "center" })

      // Add horizontal line
      doc.setDrawColor(lightGray[0], lightGray[1], lightGray[2])
      doc.line(20, 60, 190, 60)

      // Add user information section
      doc.setFontSize(14)
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2])
      doc.text("User Information", 20, 75)

      // Add user information content
      doc.setFillColor(250, 250, 255)
      doc.roundedRect(20, 80, 170, 35, 2, 2, "F")

      doc.setFontSize(10)
      doc.setTextColor(100, 100, 100)
      doc.text("Name:", 30, 90)
      doc.text("Email:", 30, 98)
      doc.text("Tests Completed:", 30, 106)
      doc.text("Average Score:", 30, 114)

      doc.setTextColor(textColor[0], textColor[1], textColor[2])
      doc.text(userData.username, 70, 90)
      doc.text(userData.email, 70, 98)
      doc.text(testResults ? testResults.length.toString() : "0", 70, 106)
      doc.text(`${averageScore}%`, 70, 114)

      // Add topic performance section
      let currentY = 130

      if (topicPerformance.length > 0) {
        doc.setFontSize(14)
        doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2])
        doc.text("Topic Performance", 20, currentY)
        currentY += 10

        // Manually create a table for topic performance
        doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2])
        doc.rect(20, currentY, 170, 8, "F")

        // Table headers
        doc.setTextColor(255, 255, 255)
        doc.setFontSize(10)
        doc.text("Topic", 25, currentY + 5)
        doc.text("Score", 120, currentY + 5)
        doc.text("Tests", 150, currentY + 5)

        currentY += 8

        // Table rows
        doc.setTextColor(textColor[0], textColor[1], textColor[2])
        topicPerformance.forEach((topic, index) => {
          // Alternate row background
          if (index % 2 === 0) {
            doc.setFillColor(245, 245, 250)
            doc.rect(20, currentY, 170, 8, "F")
          }

          // Ensure topic text doesn't overflow
          const topicText = doc.splitTextToSize(topic.topic, 90)
          doc.text(topicText, 25, currentY + 5)
          doc.text(`${topic.score}%`, 120, currentY + 5)
          doc.text(`${topic.tests}`, 150, currentY + 5)

          // Adjust row height based on text wrapping
          const rowHeight = Math.max(8, topicText.length * 5)
          currentY += rowHeight
        })

        currentY += 15
      }

      // Check if we need a new page
      if (currentY > 240) {
        doc.addPage()
        currentY = 20
      }

      // Add test results section
      if (testResults && testResults.length > 0) {
        doc.setFontSize(14)
        doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2])
        doc.text("Test Results", 20, currentY)
        currentY += 10

        // Manually create a table for results
        doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2])
        doc.rect(20, currentY, 170, 8, "F")

        // Table headers
        doc.setTextColor(255, 255, 255)
        doc.setFontSize(10)
        doc.text("Test", 25, currentY + 5)
        doc.text("Score", 120, currentY + 5)
        doc.text("Date", 150, currentY + 5)

        currentY += 8

        // Table rows
        doc.setTextColor(textColor[0], textColor[1], textColor[2])
        testResults.forEach((result, index) => {
          // Check if we need a new page
          if (currentY > 270) {
            doc.addPage()
            currentY = 20

            // Add table header on new page
            doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2])
            doc.rect(20, currentY, 170, 8, "F")

            doc.setTextColor(255, 255, 255)
            doc.text("Test", 25, currentY + 5)
            doc.text("Score", 120, currentY + 5)
            doc.text("Date", 150, currentY + 5)

            currentY += 8
            doc.setTextColor(textColor[0], textColor[1], textColor[2])
          }

          // Alternate row background
          if (index % 2 === 0) {
            doc.setFillColor(245, 245, 250)
            doc.rect(20, currentY, 170, 8, "F")
          }

          // Ensure test name doesn't overflow
          const testTitle = result.tests?.title || "Unknown Test"
          const wrappedTitle = doc.splitTextToSize(testTitle, 90)
          doc.text(wrappedTitle, 25, currentY + 5)
          doc.text(`${result.score}%`, 120, currentY + 5)
          doc.text(new Date(result.completed_at).toLocaleDateString(), 150, currentY + 5)

          // Adjust row height based on text wrapping
          const rowHeight = Math.max(8, wrappedTitle.length * 5)
          currentY += rowHeight
        })
      }

      // Add footer
      const pageCount = doc.getNumberOfPages()

      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i)

        // Footer background
        doc.setFillColor(245, 245, 250)
        doc.rect(0, 280, 210, 17, "F")

        // Footer text
        doc.setFontSize(8)
        doc.setTextColor(100, 100, 100)
        doc.text("Generated by SAMAJH AI-Powered Interview Platform", 105, 287, { align: "center" })
        doc.text(`Page ${i} of ${pageCount}`, 185, 287)
      }

      // Save the PDF
      const filename = `User_Report_${userData.username.replace(/\s+/g, "_")}.pdf`
      doc.save(filename)

      toast({
        title: "Success",
        description: "User report downloaded successfully",
      })
    } catch (error) {
      console.error("Error downloading report:", error)
      toast({
        title: "Error",
        description: "Failed to download user report",
        variant: "destructive",
      })
    } finally {
      setDownloadingPdf(false)
    }
  }

  return (
    <DashboardLayout requiredRole="admin">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <h1 className="text-3xl font-bold text-purple-800">User Management</h1>
          <div className="flex gap-2">
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                type="search"
                placeholder="Search users..."
                className="w-full pl-9 border-purple-200 focus:border-purple-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button className="bg-purple-700 hover:bg-purple-800 text-white" onClick={() => setAddUserDialogOpen(true)}>
              <UserPlus className="mr-2 h-4 w-4" />
              Add User
            </Button>
          </div>
        </div>

        <Card className="border-purple-200">
          <CardHeader>
            <CardTitle className="text-xl text-purple-800">All Users</CardTitle>
            <CardDescription>Manage users and assign tests</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-12">
                <div className="h-8 w-8 animate-spin rounded-full border-4 border-purple-200 border-t-purple-700"></div>
              </div>
            ) : filteredUsers.length === 0 ? (
              <div className="py-8 text-center text-gray-500">No users found.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-purple-100 text-left text-sm font-medium text-gray-500">
                      <th className="pb-3 pl-4">User</th>
                      <th className="pb-3">Email</th>
                      <th className="pb-3">Role</th>
                      <th className="pb-3">Last Login</th>
                      <th className="pb-3">Status</th>
                      <th className="pb-3 pr-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredUsers.map((user) => (
                      <tr key={user.id} className="border-b border-purple-100 text-sm hover:bg-purple-50">
                        <td className="py-4 pl-4">
                          <div className="flex items-center">
                            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-purple-100 text-purple-800">
                              {user.username
                                .split(" ")
                                .map((n) => n[0])
                                .join("")
                                .toUpperCase()}
                            </div>
                            <div className="ml-3">
                              <p className="font-medium text-purple-800">{user.username}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 text-gray-600">
                          <div className="flex items-center">
                            <Mail className="mr-2 h-4 w-4 text-purple-500" />
                            {user.email}
                          </div>
                        </td>
                        <td className="py-4 text-gray-600 capitalize">{user.role}</td>
                        <td className="py-4 text-gray-600">
                          {user.last_login ? new Date(user.last_login).toLocaleString() : "Never"}
                        </td>
                        <td className="py-4">
                          <Badge
                            className={`${
                              user.last_login &&
                              new Date(user.last_login).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000
                                ? "bg-green-100 text-green-800 border-green-200"
                                : "bg-gray-100 text-gray-800 border-gray-200"
                            }`}
                          >
                            {user.last_login &&
                            new Date(user.last_login).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000
                              ? "Active"
                              : "Inactive"}
                          </Badge>
                        </td>
                        <td className="py-4 pr-4">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-purple-600 hover:bg-purple-50 hover:text-purple-800"
                              >
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Actions</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem
                                className="flex items-center"
                                onClick={() => handleViewProfile(user.id)}
                              >
                                <User2 className="mr-2 h-4 w-4" />
                                <span>View Profile</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem className="flex items-center" onClick={() => handleAssignTest(user.id)}>
                                <ClipboardList className="mr-2 h-4 w-4" />
                                <span>Assign Test</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                className="flex items-center"
                                onClick={() => handleDownloadReport(user.id)}
                              >
                                <Download className="mr-2 h-4 w-4" />
                                <span>Download Report</span>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Assign Test Dialog */}
      <Dialog open={assignDialogOpen} onOpenChange={setAssignDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-purple-800">Assign Test</DialogTitle>
            <DialogDescription>
              Assign a test to {selectedUser ? users.find((u) => u.id === selectedUser)?.username : "user"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="test-status">Test Status</Label>
              <Select
                value={testStatus}
                onValueChange={(value: "active" | "draft" | "all") => handleTestStatusChange(value)}
              >
                <SelectTrigger className="border-purple-200 focus:border-purple-500">
                  <SelectValue placeholder="Select test status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active Tests</SelectItem>
                  <SelectItem value="draft">Draft Tests</SelectItem>
                  <SelectItem value="all">All Tests</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-gray-500">
                {testStatus === "draft"
                  ? "Draft tests will only be visible to this specific user"
                  : testStatus === "all"
                    ? "Select from all available tests"
                    : "Active tests are visible to all users"}
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="test">Select Test</Label>
              <Select value={selectedTest} onValueChange={setSelectedTest}>
                <SelectTrigger className="border-purple-200 focus:border-purple-500">
                  <SelectValue placeholder="Select a test" />
                </SelectTrigger>
                <SelectContent>
                  {tests.map((test) => (
                    <SelectItem key={test.id} value={test.id}>
                      {test.title} {test.status === "draft" && "(Draft)"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="dueDate">Due Date</Label>
              <Input
                id="dueDate"
                type="date"
                className="border-purple-200 focus:border-purple-500"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Input
                id="notes"
                placeholder="Add any additional instructions"
                className="border-purple-200 focus:border-purple-500"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setAssignDialogOpen(false)}
              className="border-purple-200 text-purple-700"
            >
              Cancel
            </Button>
            <Button
              onClick={handleAssignSubmit}
              className="bg-purple-700 hover:bg-purple-800 text-white"
              disabled={!selectedTest}
            >
              Assign Test
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add User Dialog */}
      <Dialog open={addUserDialogOpen} onOpenChange={setAddUserDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-purple-800">Add New User</DialogTitle>
            <DialogDescription>Create a new user account in the system.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                placeholder="Enter username"
                className={`border-purple-200 focus:border-purple-500 ${formErrors.username ? "border-red-500" : ""}`}
                value={newUser.username}
                onChange={(e) => setNewUser({ ...newUser, username: e.target.value })}
              />
              {formErrors.username && <p className="text-xs text-red-500">{formErrors.username}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter email address"
                className={`border-purple-200 focus:border-purple-500 ${formErrors.email ? "border-red-500" : ""}`}
                value={newUser.email}
                onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
              />
              {formErrors.email && <p className="text-xs text-red-500">{formErrors.email}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter password"
                className={`border-purple-200 focus:border-purple-500 ${formErrors.password ? "border-red-500" : ""}`}
                value={newUser.password}
                onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
              />
              {formErrors.password && <p className="text-xs text-red-500">{formErrors.password}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="role">Role</Label>
              <Select value={newUser.role} onValueChange={(value: "user") => setNewUser({ ...newUser, role: value })}>
                <SelectTrigger className="border-purple-200 focus:border-purple-500">
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">User</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setAddUserDialogOpen(false)}
              className="border-purple-200 text-purple-700"
            >
              Cancel
            </Button>
            <Button onClick={handleAddUser} className="bg-purple-700 hover:bg-purple-800 text-white">
              Add User
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Profile Dialog */}
      <Dialog open={viewProfileDialogOpen} onOpenChange={setViewProfileDialogOpen}>
        <DialogContent className="sm:max-w-4xl">
          <DialogHeader>
            <DialogTitle className="text-purple-800">User Profile</DialogTitle>
            <DialogDescription>Viewing profile for {profileUser?.username}</DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            {profileUser && (
              <>
                <div className="flex flex-col sm:flex-row gap-6 items-start">
                  <div className="flex h-20 w-20 items-center justify-center rounded-full bg-purple-100 text-purple-800 text-3xl">
                    {profileUser.username
                      .split(" ")
                      .map((n) => n[0])
                      .join("")
                      .toUpperCase()}
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-xl font-semibold">{profileUser.username}</h3>
                    <div className="flex items-center text-gray-600">
                      <Mail className="mr-2 h-4 w-4" />
                      {profileUser.email}
                    </div>
                    <div className="flex items-center gap-4">
                      <Badge className="capitalize">{profileUser.role}</Badge>
                      <Badge
                        className={`${
                          profileUser.last_login &&
                          new Date(profileUser.last_login).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000
                            ? "bg-green-100 text-green-800 border-green-200"
                            : "bg-gray-100 text-gray-800 border-gray-200"
                        }`}
                      >
                        {profileUser.last_login &&
                        new Date(profileUser.last_login).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000
                          ? "Active"
                          : "Inactive"}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-500">
                      Last login: {profileUser.last_login ? new Date(profileUser.last_login).toLocaleString() : "Never"}
                    </p>
                  </div>
                </div>

                <div className="border-t border-gray-200 pt-4">
                  <h4 className="text-lg font-semibold mb-4">Test Results</h4>
                  {userTestResults.length === 0 ? (
                    <p className="text-gray-500">No test results available.</p>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b border-gray-200">
                            <th className="text-left py-2 px-2 text-gray-600">Test</th>
                            <th className="text-left py-2 px-2 text-gray-600">Topic</th>
                            <th className="text-center py-2 px-2 text-gray-600">Score</th>
                            <th className="text-right py-2 px-2 text-gray-600">Date</th>
                          </tr>
                        </thead>
                        <tbody>
                          {userTestResults.map((result) => (
                            <tr key={result.id} className="border-b border-gray-100">
                              <td className="py-2 px-2">{result.tests?.title || "Unknown Test"}</td>
                              <td className="py-2 px-2">{result.tests?.topic || "Unknown Topic"}</td>
                              <td className="py-2 px-2 text-center">
                                <span
                                  className={`px-2 py-1 rounded-full text-xs ${
                                    result.score >= 80
                                      ? "bg-green-100 text-green-800"
                                      : result.score >= 60
                                        ? "bg-yellow-100 text-yellow-800"
                                        : "bg-red-100 text-red-800"
                                  }`}
                                >
                                  {result.score}%
                                </span>
                              </td>
                              <td className="py-2 px-2 text-right text-gray-500">
                                {new Date(result.completed_at).toLocaleString()}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setViewProfileDialogOpen(false)}
              className="border-purple-200 text-purple-700"
            >
              Close
            </Button>
            <Button
              onClick={() => handleDownloadReport(profileUser?.id || "")}
              className="bg-purple-700 hover:bg-purple-800 text-white"
              disabled={downloadingPdf || !profileUser}
            >
              {downloadingPdf ? (
                <>
                  <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                  Generating PDF...
                </>
              ) : (
                <>
                  <Download className="mr-2 h-4 w-4" />
                  Download Report
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  )
}
