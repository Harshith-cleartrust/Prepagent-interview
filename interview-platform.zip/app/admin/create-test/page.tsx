"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { AlertCircle, Clock, Edit, Plus, RefreshCw, Save, Trash2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Question } from "@/lib/types"
import { createTest } from "@/app/actions/tests"

interface TestFormState {
  title: string
  description: string
  topic: string
  duration: number
  totalQuestions: number
  difficulty: {
    easy: number
    intermediate: number
    hard: number
  }
  questions: Question[]
  status: "draft" | "published"
}

export default function CreateTest() {
  const router = useRouter()
  const [title, setTitle] = useState("")
  const [topic, setTopic] = useState("")
  const [description, setDescription] = useState("")
  const [duration, setDuration] = useState("60")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [questions, setQuestions] = useState<Question[]>([])
  const [activeTab, setActiveTab] = useState("details")
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null)
  const [generatingQuestions, setGeneratingQuestions] = useState(false)
  const [isAddingQuestion, setIsAddingQuestion] = useState(false)
  const [selectedDifficulties, setSelectedDifficulties] = useState({
    easy: true,
    intermediate: true,
    hard: true,
  })
  const [difficultyDistribution, setDifficultyDistribution] = useState({
    easy: 5,
    intermediate: 10,
    hard: 15,
  })
  const [totalQuestionCount, setTotalQuestionCount] = useState(40)
  const [customDistribution, setCustomDistribution] = useState(false)
  const [newQuestion, setNewQuestion] = useState<Question>({
    id: "",
    test_id: "",
    text: "",
    options: ["", "", "", ""],
    correct_answer: 0,
    difficulty: "easy",
    explanation: "",
    created_at: "",
  })

  const [formState, setFormState] = useState<TestFormState>({
    title: "",
    description: "",
    topic: "",
    duration: 60,
    totalQuestions: 40, // Changed from 45 to 40
    difficulty: {
      easy: 15, // Adjusted distribution
      intermediate: 15, // Adjusted distribution
      hard: 10, // Adjusted distribution
    },
    questions: [],
    status: "draft",
  })

  const handleDifficultyChange = (difficulty: string) => {
    setSelectedDifficulties((prev) => ({
      ...prev,
      [difficulty]: !prev[difficulty],
    }))
  }

  const getSelectedDifficulties = () => {
    return Object.entries(selectedDifficulties)
      .filter(([_, isSelected]) => isSelected)
      .map(([difficulty]) => difficulty)
  }

  const handleDifficultyCountChange = (difficulty: string, value: string) => {
    const count = Number.parseInt(value) || 0
    setDifficultyDistribution((prev) => ({
      ...prev,
      [difficulty]: count,
    }))
  }

  const generateQuestions = async () => {
    if (!topic) {
      setError("Please enter a test topic")
      return
    }

    const difficulties = getSelectedDifficulties()
    if (difficulties.length === 0) {
      setError("Please select at least one difficulty level")
      return
    }

    setError("")
    setGeneratingQuestions(true)

    try {
      // Prepare difficulty distribution if custom is enabled
      const distribution = customDistribution
        ? Object.fromEntries(
            Object.entries(difficultyDistribution).filter(([difficulty]) => selectedDifficulties[difficulty]),
          )
        : null

      const response = await fetch("/api/generate-questions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          topic,
          difficulties,
          count: totalQuestionCount,
          difficultyDistribution: distribution,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to generate questions")
      }

      const data = await response.json()

      // Add unique IDs to the questions
      const newQuestions = data.questions.map((q: any) => ({
        ...q,
        id: `${q.difficulty}-${Math.random().toString(36).substring(2, 11)}`,
        test_id: "", // This will be set when the test is created
        created_at: new Date().toISOString(),
      }))

      // Add the new questions to the existing ones
      setQuestions((prev) => [...prev, ...newQuestions])

      if (questions.length === 0 && newQuestions.length > 0) {
        setActiveTab("preview")
      }
    } catch (err) {
      console.error("Error generating questions:", err)
      setError(err instanceof Error ? err.message : "Failed to generate questions")
    } finally {
      setGeneratingQuestions(false)
    }
  }

  const handleEditQuestion = (question: Question) => {
    setEditingQuestion(question)
  }

  const handleSaveQuestion = () => {
    if (editingQuestion) {
      setQuestions(questions.map((q) => (q.id === editingQuestion.id ? editingQuestion : q)))
      setEditingQuestion(null)
    }
  }

  const handleAddNewQuestion = () => {
    setIsAddingQuestion(true)
    setNewQuestion({
      id: `manual-${Math.random().toString(36).substring(2, 11)}`,
      test_id: "",
      text: "",
      options: ["", "", "", ""],
      correct_answer: 0,
      difficulty: "easy",
      explanation: "",
      created_at: new Date().toISOString(),
    })
  }

  const handleSaveNewQuestion = () => {
    // Validate the new question
    if (!newQuestion.text || newQuestion.options.some((opt) => !opt)) {
      setError("Please fill in all question fields")
      return
    }

    setQuestions((prev) => [...prev, newQuestion])
    setIsAddingQuestion(false)
    setError("")
  }

  const handleRegenerateQuestion = async (questionId: string) => {
    const questionToRegenerate = questions.find((q) => q.id === questionId)
    if (!questionToRegenerate) return

    try {
      const response = await fetch("/api/generate-questions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          topic,
          difficulties: [questionToRegenerate.difficulty],
          count: 1,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to regenerate question")
      }

      const data = await response.json()

      if (data.questions && data.questions.length > 0) {
        const newQuestion = {
          ...data.questions[0],
          id: questionId,
          test_id: questionToRegenerate.test_id,
          created_at: new Date().toISOString(),
        }

        setQuestions(questions.map((q) => (q.id === questionId ? newQuestion : q)))
      }
    } catch (err) {
      console.error("Error regenerating question:", err)
      setError(err instanceof Error ? err.message : "Failed to regenerate question")
    }
  }

  const handleDeleteQuestion = (questionId: string) => {
    setQuestions(questions.filter((q) => q.id !== questionId))
  }

  const handleSaveTest = async () => {
    if (!title || !topic || !duration || questions.length === 0) {
      setError("Please fill in all required fields and generate questions")
      return
    }

    setLoading(true)
    setError("")

    try {
      // Create a FormData object
      const formData = new FormData()
      formData.append("title", title)
      formData.append("topic", topic)
      formData.append("description", description)
      formData.append("duration", duration)
      formData.append("questions", JSON.stringify(questions))

      console.log("Submitting test with title:", title)
      console.log("Topic:", topic)
      console.log("Duration:", duration)
      console.log("Questions count:", questions.length)

      const result = await createTest(formData)

      if (result.error) {
        setError(result.error)
        setLoading(false)
        return
      }

      router.push("/admin/tests")
    } catch (err) {
      console.error("Error saving test:", err)
      setError(err instanceof Error ? err.message : "Failed to save test")
      setLoading(false)
    }
  }

  return (
    <DashboardLayout requiredRole="admin">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-purple-800">Create Test</h1>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="details">Test Details</TabsTrigger>
            <TabsTrigger value="preview" disabled={questions.length === 0}>
              Question Preview ({questions.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="details" className="mt-6">
            <Card className="border-purple-200">
              <CardHeader>
                <CardTitle className="text-xl text-purple-800">Test Information</CardTitle>
                <CardDescription>Enter the test details and generate questions using AI</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <div className="space-y-2">
                  <Label htmlFor="title">Test Title</Label>
                  <Input
                    id="title"
                    placeholder="e.g., JavaScript Fundamentals Test"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="border-purple-200 focus:border-purple-500"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="topic">Test Topic</Label>
                  <Input
                    id="topic"
                    placeholder="e.g., JavaScript Fundamentals, React Hooks, System Design"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    className="border-purple-200 focus:border-purple-500"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Textarea
                    id="description"
                    placeholder="Enter a description for this test"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="border-purple-200 focus:border-purple-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="duration">Duration (minutes)</Label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-3 h-4 w-4 text-purple-500" />
                    <Input
                      id="duration"
                      type="number"
                      min="10"
                      max="180"
                      placeholder="60"
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      className="pl-10 border-purple-200 focus:border-purple-500"
                      required
                    />
                  </div>
                </div>

                <div className="pt-4 space-y-4">
                  <h3 className="font-medium text-purple-800">Select Difficulty Levels</h3>
                  <div className="flex flex-wrap gap-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="easy"
                        checked={selectedDifficulties.easy}
                        onCheckedChange={() => handleDifficultyChange("easy")}
                      />
                      <label
                        htmlFor="easy"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Easy
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="intermediate"
                        checked={selectedDifficulties.intermediate}
                        onCheckedChange={() => handleDifficultyChange("intermediate")}
                      />
                      <label
                        htmlFor="intermediate"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Intermediate
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="hard"
                        checked={selectedDifficulties.hard}
                        onCheckedChange={() => handleDifficultyChange("hard")}
                      />
                      <label
                        htmlFor="hard"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Hard
                      </label>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="custom-distribution"
                        checked={customDistribution}
                        onCheckedChange={(checked) => setCustomDistribution(checked === true)}
                      />
                      <label
                        htmlFor="custom-distribution"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Custom question distribution
                      </label>
                    </div>
                  </div>

                  {customDistribution ? (
                    <div className="space-y-4 p-4 border border-purple-100 rounded-md">
                      <div className="space-y-2">
                        <Label htmlFor="easy-count">Easy Questions</Label>
                        <Input
                          id="easy-count"
                          type="number"
                          min="0"
                          value={difficultyDistribution.easy}
                          onChange={(e) => handleDifficultyCountChange("easy", e.target.value)}
                          className="border-purple-200 focus:border-purple-500"
                          disabled={!selectedDifficulties.easy}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="intermediate-count">Intermediate Questions</Label>
                        <Input
                          id="intermediate-count"
                          type="number"
                          min="0"
                          value={difficultyDistribution.intermediate}
                          onChange={(e) => handleDifficultyCountChange("intermediate", e.target.value)}
                          className="border-purple-200 focus:border-purple-500"
                          disabled={!selectedDifficulties.intermediate}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="hard-count">Hard Questions</Label>
                        <Input
                          id="hard-count"
                          type="number"
                          min="0"
                          value={difficultyDistribution.hard}
                          onChange={(e) => handleDifficultyCountChange("hard", e.target.value)}
                          className="border-purple-200 focus:border-purple-500"
                          disabled={!selectedDifficulties.hard}
                        />
                      </div>
                      <div className="text-sm text-gray-500">
                        Total:{" "}
                        {Object.entries(difficultyDistribution)
                          .filter(([difficulty]) => selectedDifficulties[difficulty])
                          .reduce((sum, [_, count]) => sum + count, 0)}{" "}
                        questions
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Label htmlFor="total-count">Total Questions</Label>
                      <Input
                        id="total-count"
                        type="number"
                        min="15"
                        value={totalQuestionCount}
                        onChange={(e) => setTotalQuestionCount(Number.parseInt(e.target.value) || 45)}
                        className="border-purple-200 focus:border-purple-500"
                      />
                      <p className="text-sm text-gray-500">
                        Questions will be evenly distributed across selected difficulty levels
                      </p>
                    </div>
                  )}

                  <Button
                    onClick={generateQuestions}
                    className="w-full bg-purple-700 hover:bg-purple-800 text-white"
                    disabled={loading || !topic || generatingQuestions || getSelectedDifficulties().length === 0}
                  >
                    {generatingQuestions ? "Generating Questions..." : "Generate Questions"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="preview" className="mt-6 space-y-6">
            {editingQuestion ? (
              <Card className="border-purple-200">
                <CardHeader>
                  <CardTitle className="text-xl text-purple-800">Edit Question</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="question-text">Question</Label>
                    <Textarea
                      id="question-text"
                      value={editingQuestion.text}
                      onChange={(e) => setEditingQuestion({ ...editingQuestion, text: e.target.value })}
                      className="min-h-20 border-purple-200 focus:border-purple-500"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Options</Label>
                    {editingQuestion.options.map((option, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Input
                          value={option}
                          onChange={(e) => {
                            const newOptions = [...editingQuestion.options]
                            newOptions[index] = e.target.value
                            setEditingQuestion({ ...editingQuestion, options: newOptions })
                          }}
                          className="border-purple-200 focus:border-purple-500"
                        />
                        <div className="flex items-center">
                          <input
                            type="radio"
                            id={`correct-${index}`}
                            name="correct-answer"
                            checked={editingQuestion.correct_answer === index}
                            onChange={() => setEditingQuestion({ ...editingQuestion, correct_answer: index })}
                            className="h-4 w-4 text-purple-600 focus:ring-purple-500"
                          />
                          <Label htmlFor={`correct-${index}`} className="ml-2 text-sm">
                            Correct
                          </Label>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="explanation">Explanation</Label>
                    <Textarea
                      id="explanation"
                      value={editingQuestion.explanation || ""}
                      onChange={(e) => setEditingQuestion({ ...editingQuestion, explanation: e.target.value })}
                      className="min-h-20 border-purple-200 focus:border-purple-500"
                      placeholder="Explain why the correct answer is correct"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="difficulty">Difficulty</Label>
                    <Select
                      value={editingQuestion.difficulty}
                      onValueChange={(value: "easy" | "intermediate" | "hard") =>
                        setEditingQuestion({ ...editingQuestion, difficulty: value })
                      }
                    >
                      <SelectTrigger className="border-purple-200 focus:border-purple-500">
                        <SelectValue placeholder="Select difficulty" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="easy">Easy</SelectItem>
                        <SelectItem value="intermediate">Intermediate</SelectItem>
                        <SelectItem value="hard">Hard</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-end gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setEditingQuestion(null)}
                    className="border-purple-200 text-purple-700"
                  >
                    Cancel
                  </Button>
                  <Button onClick={handleSaveQuestion} className="bg-purple-700 hover:bg-purple-800 text-white">
                    <Save className="mr-2 h-4 w-4" />
                    Save Changes
                  </Button>
                </CardFooter>
              </Card>
            ) : isAddingQuestion ? (
              <Card className="border-purple-200">
                <CardHeader>
                  <CardTitle className="text-xl text-purple-800">Add New Question</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="new-question-text">Question</Label>
                    <Textarea
                      id="new-question-text"
                      value={newQuestion.text}
                      onChange={(e) => setNewQuestion({ ...newQuestion, text: e.target.value })}
                      className="min-h-20 border-purple-200 focus:border-purple-500"
                      placeholder="Enter your question"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Options</Label>
                    {newQuestion.options.map((option, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Input
                          value={option}
                          onChange={(e) => {
                            const newOptions = [...newQuestion.options]
                            newOptions[index] = e.target.value
                            setNewQuestion({ ...newQuestion, options: newOptions })
                          }}
                          className="border-purple-200 focus:border-purple-500"
                          placeholder={`Option ${String.fromCharCode(65 + index)}`}
                        />
                        <div className="flex items-center">
                          <input
                            type="radio"
                            id={`new-correct-${index}`}
                            name="new-correct-answer"
                            checked={newQuestion.correct_answer === index}
                            onChange={() => setNewQuestion({ ...newQuestion, correct_answer: index })}
                            className="h-4 w-4 text-purple-600 focus:ring-purple-500"
                          />
                          <Label htmlFor={`new-correct-${index}`} className="ml-2 text-sm">
                            Correct
                          </Label>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="new-explanation">Explanation</Label>
                    <Textarea
                      id="new-explanation"
                      value={newQuestion.explanation || ""}
                      onChange={(e) => setNewQuestion({ ...newQuestion, explanation: e.target.value })}
                      className="min-h-20 border-purple-200 focus:border-purple-500"
                      placeholder="Explain why the correct answer is correct"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="new-difficulty">Difficulty</Label>
                    <Select
                      value={newQuestion.difficulty}
                      onValueChange={(value: "easy" | "intermediate" | "hard") =>
                        setNewQuestion({ ...newQuestion, difficulty: value })
                      }
                    >
                      <SelectTrigger className="border-purple-200 focus:border-purple-500">
                        <SelectValue placeholder="Select difficulty" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="easy">Easy</SelectItem>
                        <SelectItem value="intermediate">Intermediate</SelectItem>
                        <SelectItem value="hard">Hard</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-end gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setIsAddingQuestion(false)}
                    className="border-purple-200 text-purple-700"
                  >
                    Cancel
                  </Button>
                  <Button onClick={handleSaveNewQuestion} className="bg-purple-700 hover:bg-purple-800 text-white">
                    <Save className="mr-2 h-4 w-4" />
                    Add Question
                  </Button>
                </CardFooter>
              </Card>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold text-purple-800">Questions Preview</h2>
                  <div className="flex gap-2">
                    <Button
                      onClick={handleAddNewQuestion}
                      variant="outline"
                      className="border-purple-200 text-purple-700"
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Add Question
                    </Button>
                    <Button
                      onClick={handleSaveTest}
                      className="bg-purple-700 hover:bg-purple-800 text-white"
                      disabled={loading}
                    >
                      <Save className="mr-2 h-4 w-4" />
                      {loading ? "Saving..." : "Save Test"}
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-4">
                    <div className="flex flex-wrap gap-4 mb-4">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="add-easy"
                          checked={selectedDifficulties.easy}
                          onCheckedChange={() => handleDifficultyChange("easy")}
                        />
                        <label
                          htmlFor="add-easy"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Easy
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="add-intermediate"
                          checked={selectedDifficulties.intermediate}
                          onCheckedChange={() => handleDifficultyChange("intermediate")}
                        />
                        <label
                          htmlFor="add-intermediate"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Intermediate
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="add-hard"
                          checked={selectedDifficulties.hard}
                          onCheckedChange={() => handleDifficultyChange("hard")}
                        />
                        <label
                          htmlFor="add-hard"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Hard
                        </label>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="additional-questions">Number of Questions to Generate</Label>
                      <Input
                        id="additional-questions"
                        type="number"
                        min="1"
                        max="20"
                        value={totalQuestionCount}
                        onChange={(e) => setTotalQuestionCount(Number.parseInt(e.target.value) || 5)}
                        className="border-purple-200 focus:border-purple-500"
                      />
                      <p className="text-xs text-gray-500">Enter how many additional questions you want to generate</p>
                    </div>

                    <Button
                      onClick={generateQuestions}
                      className="w-full bg-purple-700 hover:bg-purple-800 text-white"
                      disabled={loading || !topic || generatingQuestions || getSelectedDifficulties().length === 0}
                    >
                      {generatingQuestions ? "Generating Questions..." : "Generate More Questions"}
                    </Button>
                  </div>

                  {/* Questions by difficulty */}
                  {["easy", "intermediate", "hard"].map((difficulty) => (
                    <div key={difficulty} className="space-y-2">
                      <h3 className="text-lg font-semibold capitalize text-purple-700">{difficulty} Questions</h3>
                      {questions
                        .filter((q) => q.difficulty === difficulty)
                        .map((question, index) => (
                          <Card key={question.id} className="border-purple-200">
                            <CardHeader className="pb-2">
                              <div className="flex items-center justify-between">
                                <CardTitle className="text-base text-purple-800">Question {index + 1}</CardTitle>
                                <div className="flex gap-1">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleEditQuestion(question)}
                                    className="h-8 w-8 text-purple-600 hover:bg-purple-50 hover:text-purple-800"
                                  >
                                    <Edit className="h-4 w-4" />
                                    <span className="sr-only">Edit</span>
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleRegenerateQuestion(question.id)}
                                    className="h-8 w-8 text-purple-600 hover:bg-purple-50 hover:text-purple-800"
                                  >
                                    <RefreshCw className="h-4 w-4" />
                                    <span className="sr-only">Regenerate</span>
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleDeleteQuestion(question.id)}
                                    className="h-8 w-8 text-red-600 hover:bg-red-50 hover:text-red-800"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                    <span className="sr-only">Delete</span>
                                  </Button>
                                </div>
                              </div>
                            </CardHeader>
                            <CardContent>
                              <p className="mb-2">{question.text}</p>
                              <div className="space-y-1">
                                {question.options.map((option, optionIndex) => (
                                  <div
                                    key={optionIndex}
                                    className={`rounded-md p-2 ${
                                      optionIndex === question.correct_answer
                                        ? "bg-green-50 border border-green-200"
                                        : "bg-gray-50"
                                    }`}
                                  >
                                    <span className="font-medium mr-2">{String.fromCharCode(65 + optionIndex)}.</span>
                                    {option}
                                    {optionIndex === question.correct_answer && (
                                      <span className="ml-2 text-xs text-green-600 font-medium">(Correct Answer)</span>
                                    )}
                                  </div>
                                ))}
                              </div>
                              {question.explanation && (
                                <div className="mt-2 text-sm text-gray-600">
                                  <p className="font-medium">Explanation:</p>
                                  <p>{question.explanation}</p>
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        ))}
                      {questions.filter((q) => q.difficulty === difficulty).length === 0 && (
                        <p className="text-gray-500">No {difficulty} questions added yet</p>
                      )}
                    </div>
                  ))}
                </div>
              </>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
