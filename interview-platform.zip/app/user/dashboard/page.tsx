"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Award, BookOpen, CheckCircle, Clock, FileText } from "lucide-react"
import Link from "next/link"
import { supabase } from "@/lib/supabase/client"
import type { Test, TestResult } from "@/lib/types"

export default function UserDashboard() {
  const [activeTests, setActiveTests] = useState<Test[]>([])
  const [recentResults, setRecentResults] = useState<TestResult[]>([])
  const [stats, setStats] = useState({
    testsCompleted: 0,
    averageScore: "0%",
    activeTests: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Get the current user ID from cookies
        const cookies = document.cookie.split("; ")
        const userIdCookie = cookies.find((cookie) => cookie.startsWith("user_id="))
        const userId = userIdCookie ? userIdCookie.split("=")[1] : null

        if (!userId) {
          console.error("User ID not found in cookies")
          setLoading(false)
          return
        }

        // Fetch active tests assigned to the user
        const { data: userTests, error: userTestsError } = await supabase
          .from("user_tests")
          .select(`
            test_id,
            due_date,
            status,
            tests (
              id,
              title,
              description,
              topic,
              duration,
              status
            )
          `)
          .eq("user_id", userId)
          .eq("status", "assigned")
          .order("due_date", { ascending: true })
          .limit(2)

        if (userTestsError) {
          console.error("Error fetching user tests:", userTestsError)
        } else {
          console.log("Dashboard user tests data:", userTests)

          // Extract the tests from the user_tests data
          const tests = userTests
            .filter((test) => test.tests)
            .map((userTest) => ({
              ...userTest.tests,
              due_date: userTest.due_date,
            }))

          console.log("Dashboard processed tests:", tests)
          setActiveTests(tests)
        }

        // Get total active tests count
        const { count: totalActive, error: activeCountError } = await supabase
          .from("user_tests")
          .select("*", { count: "exact", head: true })
          .eq("user_id", userId)
          .eq("status", "assigned")

        if (activeCountError) {
          console.error("Error fetching active tests count:", activeCountError)
        } else {
          setStats((prev) => ({ ...prev, activeTests: totalActive || 0 }))
        }

        // Fetch test results
        const { data: results, error: resultsError } = await supabase
          .from("test_results")
          .select(`
            id,
            score,
            completed_at,
            test_id,
            tests (
              id,
              title,
              topic
            )
          `)
          .eq("user_id", userId)
          .order("completed_at", { ascending: false })
          .limit(2)

        if (resultsError) {
          console.error("Error fetching test results:", resultsError)
        } else {
          setRecentResults(results)

          // Get all test results for accurate average calculation
          const { data: allResults, error: allResultsError } = await supabase
            .from("test_results")
            .select("score")
            .eq("user_id", userId)

          if (allResultsError) {
            console.error("Error fetching all test results:", allResultsError)
          } else {
            // Calculate stats
            const completedCount = allResults.length
            const totalScore = allResults.reduce((sum, result) => sum + (result.score || 0), 0)
            const avgScore = completedCount > 0 ? Math.round(totalScore / completedCount) : 0

            // Get total completed tests count
            const { count: totalCompleted, error: countError } = await supabase
              .from("test_results")
              .select("*", { count: "exact", head: true })
              .eq("user_id", userId)

            if (countError) {
              console.error("Error fetching completed tests count:", countError)
            }

            setStats({
              testsCompleted: totalCompleted || completedCount,
              averageScore: `${avgScore}%`,
              activeTests: totalActive || 0,
            })
          }
        }
      } catch (error) {
        console.error("Error fetching dashboard data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))

    if (diffDays === 0) return "Today"
    if (diffDays === 1) return "Yesterday"
    if (diffDays < 7) return `${diffDays} days ago`
    return date.toLocaleDateString()
  }

  const formatDueDate = (dateString: string | null) => {
    if (!dateString) return "No due date"

    const dueDate = new Date(dateString)
    const now = new Date()
    const diffDays = Math.floor((dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))

    if (diffDays < 0) return "Overdue"
    if (diffDays === 0) return "Today"
    if (diffDays === 1) return "Tomorrow"
    if (diffDays < 7) return `In ${diffDays} days`
    return dueDate.toLocaleDateString()
  }

  if (loading) {
    return (
      <DashboardLayout requiredRole="user">
        <div className="flex justify-center py-12">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-purple-200 border-t-purple-700"></div>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout requiredRole="user">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-purple-800">Your Dashboard</h1>

        <div className="grid gap-6 md:grid-cols-3">
          <Card className="border-purple-200">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium text-gray-500">Tests Completed</CardTitle>
              <CheckCircle className="h-5 w-5 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-800">{stats.testsCompleted}</div>
            </CardContent>
          </Card>

          <Card className="border-purple-200">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium text-gray-500">Average Score</CardTitle>
              <Award className="h-5 w-5 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-800">{stats.averageScore}</div>
            </CardContent>
          </Card>

          <Card className="border-purple-200">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium text-gray-500">Active Tests</CardTitle>
              <BookOpen className="h-5 w-5 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-800">{stats.activeTests}</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="border-purple-200">
            <CardHeader>
              <CardTitle className="text-xl text-purple-800">Active Tests</CardTitle>
              <CardDescription>Tests assigned to you that need to be completed</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {activeTests.length > 0 ? (
                  activeTests.map((test) => (
                    <div key={test.id} className="rounded-lg border border-purple-100 p-4">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium text-purple-800">{test.title}</h3>
                        <div className="rounded-full bg-purple-100 px-2 py-1 text-xs font-medium text-purple-800">
                          Due: {formatDueDate(test.due_date || null)}
                        </div>
                      </div>
                      <div className="mt-2 flex items-center text-sm text-gray-500">
                        <Clock className="mr-1 h-4 w-4 text-purple-500" />
                        {test.duration} min
                        <FileText className="ml-3 mr-1 h-4 w-4 text-purple-500" />
                        {test.topic}
                        {test.status === "draft" && (
                          <span className="ml-3 rounded-full bg-yellow-100 px-2 py-0.5 text-xs font-medium text-yellow-800">
                            Draft
                          </span>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="py-8 text-center text-gray-500">No active tests assigned to you.</div>
                )}
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild className="w-full bg-purple-700 hover:bg-purple-800 text-white">
                <Link href="/user/active-tests">View All Active Tests</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card className="border-purple-200">
            <CardHeader>
              <CardTitle className="text-xl text-purple-800">Recent Results</CardTitle>
              <CardDescription>Your performance in recently completed tests</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentResults.length > 0 ? (
                  recentResults.map((result) => (
                    <div key={result.id} className="rounded-lg border border-purple-100 p-4">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium text-purple-800">{result.tests?.title || "Unknown Test"}</h3>
                        <div className="rounded-full bg-green-100 px-2 py-1 text-xs font-medium text-green-800">
                          {result.score}%
                        </div>
                      </div>
                      <div className="mt-2 text-sm text-gray-500">Completed {formatDate(result.completed_at)}</div>
                    </div>
                  ))
                ) : (
                  <div className="py-8 text-center text-gray-500">
                    No test results yet. Complete a test to see your results here.
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild className="w-full bg-purple-700 hover:bg-purple-800 text-white">
                <Link href="/user/history">View All Results</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
