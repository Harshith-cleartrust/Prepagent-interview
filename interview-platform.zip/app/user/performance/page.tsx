"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Award, BookOpen, Brain, FileText, Target } from "lucide-react"
import { getUserPerformanceData } from "@/app/actions/results"
import { analyzeUserPerformance } from "@/lib/analytics-service"
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts"

// Define the type for our analytics data
type UserAnalytics = {
  performanceData: Array<{ month: string; score: number }>
  topicPerformance: Array<{ topic: string; score: number; tests: number }>
  skillGaps: Array<{ skill: string; score: number }>
  recommendations: string[]
  stats: {
    testsCompleted: number
    averageScore: number
    improvement: number
  }
  testResults: any[]
  aiInsights?: string
}

export default function UserPerformance() {
  const [analytics, setAnalytics] = useState<UserAnalytics | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [aiInsights, setAiInsights] = useState<string | null>(null)
  const [insightsLoading, setInsightsLoading] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      try {
        console.log("Fetching performance data...")
        const data = await getUserPerformanceData()
        console.log("Performance data received:", data)

        if (data) {
          setAnalytics(data)

          // Generate AI insights based on the user's performance data
          if (data.testResults && data.testResults.length > 0) {
            setInsightsLoading(true)
            try {
              const insights = await analyzeUserPerformance(data.testResults)
              setAiInsights(insights)
            } catch (insightError) {
              console.error("Error generating AI insights:", insightError)
              setAiInsights("Unable to generate AI insights at this time. Please try again later.")
            } finally {
              setInsightsLoading(false)
            }
          }
        }
      } catch (error) {
        console.error("Error fetching performance data:", error)
        setError("Failed to load performance data. Please try again later.")
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  if (loading) {
    return (
      <DashboardLayout requiredRole="user">
        <div className="flex justify-center py-12">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-purple-200 border-t-purple-700"></div>
        </div>
      </DashboardLayout>
    )
  }

  if (error) {
    return (
      <DashboardLayout requiredRole="user">
        <div className="space-y-4">
          <h1 className="text-3xl font-bold text-purple-800">Performance Analysis</h1>
          <Card className="border-purple-200">
            <CardContent className="py-10 text-center">
              <p className="text-red-500">{error}</p>
              <Button onClick={() => window.location.reload()} className="mt-4">
                Try Again
              </Button>
            </CardContent>
          </Card>
        </div>
      </DashboardLayout>
    )
  }

  if (!analytics || analytics.stats.testsCompleted === 0) {
    return (
      <DashboardLayout requiredRole="user">
        <div className="space-y-4">
          <h1 className="text-3xl font-bold text-purple-800">Performance Analysis</h1>
          <Card className="border-purple-200">
            <CardContent className="py-10 text-center">
              <p className="text-gray-500">No performance data available yet. Take some tests to see your progress!</p>
              <Button asChild className="mt-4">
                <a href="/user/active-tests">Take a Test</a>
              </Button>
            </CardContent>
          </Card>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout requiredRole="user">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-purple-800">Performance Analysis</h1>

        <div className="grid gap-6 md:grid-cols-3">
          <Card className="border-purple-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl text-purple-800">Tests Completed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center">
                <div className="text-4xl font-bold text-purple-800">{analytics.stats.testsCompleted}</div>
                <p className="text-sm text-gray-500">Total tests taken</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-purple-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl text-purple-800">Average Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center">
                <div className="text-4xl font-bold text-purple-800">{analytics.stats.averageScore}%</div>
                <p className="text-sm text-gray-500">Across all tests</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-purple-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl text-purple-800">Improvement</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center">
                <div className="text-4xl font-bold text-purple-800">
                  {analytics.stats.improvement > 0 ? "+" : ""}
                  {analytics.stats.improvement}%
                </div>
                <p className="text-sm text-gray-500">In the last 30 days</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Performance Chart */}
        {analytics.performanceData &&
          analytics.performanceData.length > 0 &&
          analytics.performanceData.some((item) => item.score > 0) && (
            <Card className="border-purple-200">
              <CardHeader>
                <CardTitle className="text-xl text-purple-800">Performance Trend</CardTitle>
                <CardDescription>Your test scores over the past 6 months</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analytics.performanceData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis domain={[0, 100]} />
                      <Tooltip />
                      <Bar dataKey="score" fill="#8884d8" name="Score (%)" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}

        {/* AI Insights Section */}
        <Card className="border-purple-200">
          <CardHeader>
            <CardTitle className="text-xl text-purple-800">AI Insights</CardTitle>
            <CardDescription>Personalized AI analysis of your performance</CardDescription>
          </CardHeader>
          <CardContent>
            {insightsLoading ? (
              <div className="flex justify-center py-6">
                <div className="h-6 w-6 animate-spin rounded-full border-4 border-purple-200 border-t-purple-700"></div>
                <span className="ml-3 text-purple-800">Generating insights...</span>
              </div>
            ) : aiInsights ? (
              <div className="rounded-lg bg-purple-50 p-4 border border-purple-100">
                <div className="flex items-center gap-2 mb-2">
                  <Brain className="h-5 w-5 text-purple-700" />
                  <h3 className="font-medium text-purple-800">Performance Analysis</h3>
                </div>
                <div className="text-gray-700 whitespace-pre-line">{aiInsights}</div>
              </div>
            ) : (
              <p className="text-gray-500 text-center py-4">
                No insights available. Complete more tests to receive personalized analysis.
              </p>
            )}
          </CardContent>
        </Card>

        <div className="grid gap-6 md:grid-cols-2">
          {analytics.topicPerformance && analytics.topicPerformance.length > 0 && (
            <Card className="border-purple-200">
              <CardHeader>
                <CardTitle className="text-xl text-purple-800">Topic Performance</CardTitle>
                <CardDescription>Your performance across different topics</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {analytics.topicPerformance.map((topic, index) => (
                  <div key={index}>
                    <div className="mb-1 flex justify-between text-sm">
                      <span>{topic.topic}</span>
                      <span>{topic.score}%</span>
                    </div>
                    <Progress
                      value={topic.score}
                      className="h-2 bg-purple-100"
                      indicatorClassName={`${
                        topic.score >= 80 ? "bg-green-500" : topic.score >= 60 ? "bg-blue-500" : "bg-orange-500"
                      }`}
                    />
                    <p className="mt-1 text-xs text-gray-500">{topic.tests} tests taken</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {analytics.skillGaps && analytics.skillGaps.length > 0 && (
            <Card className="border-purple-200">
              <CardHeader>
                <CardTitle className="text-xl text-purple-800">Skill Gaps</CardTitle>
                <CardDescription>Areas that need improvement</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {analytics.skillGaps.map((skill, index) => (
                  <div key={index}>
                    <div className="mb-1 flex justify-between text-sm">
                      <span>{skill.skill}</span>
                      <span>{skill.score}% gap</span>
                    </div>
                    <Progress
                      value={skill.score}
                      className="h-2 bg-purple-100"
                      indicatorClassName={`${
                        skill.score >= 30 ? "bg-red-500" : skill.score >= 20 ? "bg-orange-500" : "bg-yellow-500"
                      }`}
                    />
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </div>

        {analytics.recommendations && analytics.recommendations.length > 0 && (
          <Card className="border-purple-200">
            <CardHeader>
              <CardTitle className="text-xl text-purple-800">Recommendations</CardTitle>
              <CardDescription>Personalized suggestions to improve your performance</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {analytics.recommendations.map((recommendation, index) => (
                  <li key={index} className="flex items-start">
                    <div className="mr-3 mt-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-purple-100 text-purple-800">
                      {index === 0 ? (
                        <Target className="h-4 w-4" />
                      ) : index === 1 ? (
                        <Brain className="h-4 w-4" />
                      ) : index === 2 ? (
                        <BookOpen className="h-4 w-4" />
                      ) : index === 3 ? (
                        <FileText className="h-4 w-4" />
                      ) : (
                        <Award className="h-4 w-4" />
                      )}
                    </div>
                    <p className="text-gray-700">{recommendation}</p>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}

        {analytics.testResults && analytics.testResults.length > 0 && (
          <Card className="border-purple-200">
            <CardHeader>
              <CardTitle className="text-xl text-purple-800">Recent Test Results</CardTitle>
              <CardDescription>Your most recent test completions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analytics.testResults.slice(0, 5).map((result, index) => (
                  <div key={index} className="flex items-center justify-between border-b pb-2">
                    <div>
                      <p className="font-medium">{result.tests?.title || "Unknown Test"}</p>
                      <p className="text-sm text-gray-500">{new Date(result.completed_at).toLocaleDateString()}</p>
                    </div>
                    <div
                      className={`rounded-full px-3 py-1 text-sm font-medium ${
                        result.score >= 80
                          ? "bg-green-100 text-green-800"
                          : result.score >= 60
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-red-100 text-red-800"
                      }`}
                    >
                      {result.score}%
                    </div>
                  </div>
                ))}
                {analytics.testResults.length > 5 && (
                  <div className="text-center">
                    <Button variant="link" asChild>
                      <a href="/user/history" className="text-purple-600 hover:text-purple-800">
                        View all test results
                      </a>
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  )
}
