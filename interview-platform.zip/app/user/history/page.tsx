"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Award, Calendar, Clock, Eye, MoreHorizontal, Search } from "lucide-react"
import Link from "next/link"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { supabase } from "@/lib/supabase/client"
import type { TestResult } from "@/lib/types"

export default function TestHistory() {
  const [searchQuery, setSearchQuery] = useState("")
  const [testResults, setTestResults] = useState<TestResult[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchTestHistory = async () => {
      try {
        // Get the current user ID from cookies
        const cookies = document.cookie.split("; ")
        const userIdCookie = cookies.find((cookie) => cookie.startsWith("user_id="))
        const userId = userIdCookie ? userIdCookie.split("=")[1] : null

        if (!userId) {
          console.error("User ID not found in cookies")
          setLoading(false)
          return
        }

        // Fetch test results for the user with test details
        const { data, error } = await supabase
          .from("test_results")
          .select(`
            id,
            score,
            time_taken,
            completed_at,
            test_id,
            tests (
              id,
              title,
              topic,
              duration
            )
          `)
          .eq("user_id", userId)
          .order("completed_at", { ascending: false })

        if (error) {
          console.error("Error fetching test results:", error)
          setLoading(false)
          return
        }

        setTestResults(data || [])
      } catch (error) {
        console.error("Error fetching test history:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchTestHistory()
  }, [])

  const filteredResults = testResults.filter(
    (result) =>
      result.tests?.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      result.tests?.topic?.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })
  }

  const formatTime = (seconds: number | null) => {
    if (!seconds) return "N/A"

    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  if (loading) {
    return (
      <DashboardLayout requiredRole="user">
        <div className="flex justify-center py-12">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-purple-200 border-t-purple-700"></div>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout requiredRole="user">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <h1 className="text-3xl font-bold text-purple-800">Test History</h1>
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              type="search"
              placeholder="Search tests..."
              className="w-full pl-9 border-purple-200 focus:border-purple-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <Card className="border-purple-200">
          <CardHeader>
            <CardTitle className="text-xl text-purple-800">Completed Tests</CardTitle>
            <CardDescription>Your past test results and performance</CardDescription>
          </CardHeader>
          <CardContent>
            {filteredResults.length === 0 ? (
              <div className="py-8 text-center text-gray-500">
                {testResults.length === 0
                  ? "You haven't completed any tests yet."
                  : "No tests match your search criteria."}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-purple-100 text-left text-sm font-medium text-gray-500">
                      <th className="pb-3 pl-4">Test Name</th>
                      <th className="pb-3">Date</th>
                      <th className="pb-3">Time Taken</th>
                      <th className="pb-3">Topic</th>
                      <th className="pb-3">Score</th>
                      <th className="pb-3 pr-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredResults.map((result) => (
                      <tr key={result.id} className="border-b border-purple-100 text-sm hover:bg-purple-50">
                        <td className="py-4 pl-4 font-medium text-purple-800">
                          {result.tests?.title || "Unknown Test"}
                        </td>
                        <td className="py-4 text-gray-600">
                          <div className="flex items-center">
                            <Calendar className="mr-2 h-4 w-4 text-purple-500" />
                            {formatDate(result.completed_at)}
                          </div>
                        </td>
                        <td className="py-4 text-gray-600">
                          <div className="flex items-center">
                            <Clock className="mr-2 h-4 w-4 text-purple-500" />
                            {formatTime(result.time_taken)}
                          </div>
                        </td>
                        <td className="py-4 text-gray-600">{result.tests?.topic || "Unknown"}</td>
                        <td className="py-4">
                          <Badge
                            className={`${
                              result.score >= 80
                                ? "bg-green-100 text-green-800 border-green-200"
                                : result.score >= 60
                                  ? "bg-blue-100 text-blue-800 border-blue-200"
                                  : "bg-amber-100 text-amber-800 border-amber-200"
                            }`}
                          >
                            <Award className="mr-1 h-3 w-3" />
                            {result.score}%
                          </Badge>
                        </td>
                        <td className="py-4 pr-4">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-purple-600 hover:bg-purple-50 hover:text-purple-800"
                              >
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Actions</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem asChild>
                                <Link href={`/user/test-results/${result.test_id}`} className="flex items-center">
                                  <Eye className="mr-2 h-4 w-4" />
                                  <span>View Details</span>
                                </Link>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
