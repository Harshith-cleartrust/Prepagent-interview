"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Award, Check, ChevronDown, ChevronUp, Download, FileText, Home, X } from "lucide-react"
import Link from "next/link"
import { getTestResult } from "@/app/actions/results"
import { getTestWithQuestions } from "@/app/actions/tests"
import { analyzeUserPerformance, generateRecommendations } from "@/lib/analytics-service"
import type { TestResult, TestWithQuestions } from "@/lib/types"

export default function TestResults({ params }: { params: { id: string } }) {
  const testId = params.id
  const [result, setResult] = useState<TestResult | null>(null)
  const [test, setTest] = useState<TestWithQuestions | null>(null)
  const [expandedQuestions, setExpandedQuestions] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [analysis, setAnalysis] = useState<{
    strengths: { topic: string; details: string }[]
    weaknesses: { topic: string; details: string }[]
    recommendations: string[]
    skillGaps: { skill: string; score: number }[]
  } | null>(null)

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch test result
        const resultData = await getTestResult(testId)
        if (!resultData) {
          setError("Test result not found")
          return
        }
        setResult(resultData)

        // Fetch test with questions
        const testData = await getTestWithQuestions(testId)
        if (!testData) {
          setError("Test not found")
          return
        }
        setTest(testData)

        // Once we have both test and result data, analyze performance
        if (resultData && testData) {
          await analyzePerformance(resultData, testData)
        }
      } catch (err) {
        console.error("Error fetching test result:", err)
        setError("Failed to load test result")
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [testId])

  const analyzePerformance = async (resultData: TestResult, testData: TestWithQuestions) => {
    try {
      // Calculate topic performance for AI analysis
      const topicPerformance = calculateTopicPerformance(resultData, testData)

      // Prepare data for AI analysis
      const analysisData = {
        test: {
          title: testData.title,
          topic: testData.topic,
          difficulty: testData.difficulty,
          questions: testData.questions.map((q) => ({
            id: q.id,
            text: q.text,
            topic: q.topic || testData.topic,
            difficulty: q.difficulty,
            userAnswer: resultData.answers[q.id],
            correctAnswer: q.correct_answer,
            isCorrect: resultData.answers[q.id] === q.correct_answer,
          })),
        },
        result: {
          score: resultData.score,
          timeTaken: resultData.time_taken,
          completedAt: resultData.completed_at,
        },
        topicPerformance: Object.entries(topicPerformance).map(([topic, data]) => ({
          topic,
          correct: data.correct,
          total: data.total,
          percentage: data.percentage,
        })),
      }

      // Get detailed analysis from AI
      const analysisText = await analyzeUserPerformance(analysisData)

      // Parse the analysis to extract strengths and weaknesses with details
      const strengthsRegex = /Strengths:([\s\S]*?)(?=Weaknesses:|$)/i
      const weaknessesRegex = /Weaknesses:([\s\S]*?)(?=\n\n|$)/i

      const strengthsMatch = analysisText.match(strengthsRegex)
      const weaknessesMatch = analysisText.match(weaknessesRegex)

      const strengthsList = strengthsMatch
        ? strengthsMatch[1]
            .split("\n")
            .filter((s) => s.trim())
            .map((s) => {
              const parts = s.replace(/^[-*•\s]+/, "").split(":")
              return {
                topic: parts[0]?.trim() || "",
                details: parts[1]?.trim() || parts[0]?.trim() || "",
              }
            })
        : []

      const weaknessesList = weaknessesMatch
        ? weaknessesMatch[1]
            .split("\n")
            .filter((s) => s.trim())
            .map((s) => {
              const parts = s.replace(/^[-*•\s]+/, "").split(":")
              return {
                topic: parts[0]?.trim() || "",
                details: parts[1]?.trim() || parts[0]?.trim() || "",
              }
            })
        : []

      // If we couldn't extract strengths or weaknesses from the AI response,
      // generate some based on the topic performance
      const finalStrengths =
        strengthsList.length > 0
          ? strengthsList
          : Object.entries(topicPerformance)
              .filter(([_, data]) => data.percentage >= 70)
              .sort((a, b) => b[1].percentage - a[1].percentage)
              .slice(0, 3)
              .map(([topic, data]) => ({
                topic,
                details: `Strong understanding of ${topic} concepts (${data.percentage}% correct)`,
              }))

      const finalWeaknesses =
        weaknessesList.length > 0
          ? weaknessesList
          : Object.entries(topicPerformance)
              .filter(([_, data]) => data.percentage < 70)
              .sort((a, b) => a[1].percentage - b[1].percentage)
              .slice(0, 3)
              .map(([topic, data]) => ({
                topic,
                details: `Needs improvement in ${topic} fundamentals (${data.percentage}% correct)`,
              }))

      // Calculate skill gaps based on question performance
      const skillGaps = calculateSkillGaps(resultData, testData)

      // Generate recommendations using AI
      const recommendations = await generateRecommendations([
        ...Object.entries(topicPerformance).map(([topic, data]) => ({
          topic,
          score: data.percentage,
          tests: 1,
        })),
        ...skillGaps.map((gap) => ({
          topic: gap.skill,
          score: 100 - gap.score,
          tests: 1,
        })),
      ])

      setAnalysis({
        strengths: finalStrengths,
        weaknesses: finalWeaknesses,
        recommendations,
        skillGaps,
      })
    } catch (error) {
      console.error("Error analyzing performance:", error)
      // Set default analysis if AI fails
      const topicPerformance = calculateTopicPerformance(result!, test!)

      setAnalysis({
        strengths: calculateTopStrengths(result!, test!).map((topic) => ({
          topic,
          details: `Strong understanding of ${topic} concepts`,
        })),
        weaknesses: calculateTopWeaknesses(result!, test!).map((topic) => ({
          topic,
          details: `Needs improvement in ${topic} fundamentals`,
        })),
        recommendations: [
          "Focus on improving your understanding of topics with lower scores",
          "Review explanations for questions you answered incorrectly",
          "Take more tests to improve your performance",
          "Consider studying additional resources for challenging topics",
          "Practice regularly to maintain your skills",
        ],
        skillGaps: calculateSkillGaps(result!, test!),
      })
    }
  }

  // Calculate skill gaps based on question performance
  const calculateSkillGaps = (resultData: TestResult, testData: TestWithQuestions) => {
    // Group questions by skills they test
    const skillPerformance: Record<string, { correct: number; total: number }> = {}

    testData.questions.forEach((question) => {
      // Extract skills from question text or use topic as fallback
      const skills = extractSkillsFromQuestion(question) || [question.topic || testData.topic]

      skills.forEach((skill) => {
        if (!skillPerformance[skill]) {
          skillPerformance[skill] = { correct: 0, total: 0 }
        }

        skillPerformance[skill].total++

        if (resultData.answers[question.id] === question.correct_answer) {
          skillPerformance[skill].correct++
        }
      })
    })

    // Calculate gap score (100 - performance percentage)
    return Object.entries(skillPerformance)
      .map(([skill, data]) => ({
        skill,
        score: 100 - Math.round((data.correct / data.total) * 100),
      }))
      .filter((gap) => gap.score > 20) // Only include significant gaps
      .sort((a, b) => b.score - a.score)
      .slice(0, 5) // Top 5 skill gaps
  }

  // Extract skills from question text using keywords
  const extractSkillsFromQuestion = (question: any) => {
    const text = question.text.toLowerCase()
    const explanation = (question.explanation || "").toLowerCase()
    const combinedText = text + " " + explanation

    const skillKeywords: Record<string, string[]> = {
      "Problem Solving": ["solve", "problem", "solution", "approach", "algorithm"],
      "Critical Thinking": ["analyze", "evaluate", "critique", "reason", "logic"],
      "Technical Knowledge": ["concept", "principle", "theory", "technical", "knowledge"],
      Application: ["apply", "implement", "use", "utilize", "practice"],
      Communication: ["explain", "describe", "articulate", "communicate", "express"],
      "Attention to Detail": ["detail", "specific", "precise", "accuracy", "careful"],
    }

    const matchedSkills = Object.entries(skillKeywords)
      .filter(([_, keywords]) => keywords.some((keyword) => combinedText.includes(keyword)))
      .map(([skill]) => skill)

    return matchedSkills.length > 0 ? matchedSkills : null
  }

  const toggleQuestion = (questionId: string) => {
    setExpandedQuestions((prev) =>
      prev.includes(questionId) ? prev.filter((id) => id !== questionId) : [...prev, questionId],
    )
  }

  const isQuestionExpanded = (questionId: string) => {
    return expandedQuestions.includes(questionId)
  }

  const formatTime = (seconds: number | null) => {
    if (!seconds) return "N/A"

    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  // Calculate performance by difficulty
  const calculatePerformanceByDifficulty = () => {
    if (!test || !result) return null

    const performance = {
      easy: { correct: 0, total: 0 },
      intermediate: { correct: 0, total: 0 },
      hard: { correct: 0, total: 0 },
    }

    test.questions.forEach((question) => {
      const difficulty = question.difficulty as keyof typeof performance
      performance[difficulty].total++

      if (result.answers[question.id] === question.correct_answer) {
        performance[difficulty].correct++
      }
    })

    return performance
  }

  // Calculate topic performance
  const calculateTopicPerformance = (resultData: TestResult, testData: TestWithQuestions) => {
    const topicPerformance: Record<string, { correct: number; total: number; percentage: number }> = {}

    // Group questions by topic and calculate performance
    testData.questions.forEach((question) => {
      const topic = question.topic || testData.topic

      if (!topicPerformance[topic]) {
        topicPerformance[topic] = { correct: 0, total: 0, percentage: 0 }
      }

      topicPerformance[topic].total++

      if (resultData.answers[question.id] === question.correct_answer) {
        topicPerformance[topic].correct++
      }
    })

    // Calculate percentage for each topic
    Object.keys(topicPerformance).forEach((topic) => {
      const { correct, total } = topicPerformance[topic]
      topicPerformance[topic].percentage = total > 0 ? Math.round((correct / total) * 100) : 0
    })

    return topicPerformance
  }

  // Calculate strengths and weaknesses
  const calculateTopStrengths = (resultData: TestResult, testData: TestWithQuestions) => {
    const topicPerformance = calculateTopicPerformance(resultData, testData)

    // Sort by percentage
    const topicScores = Object.entries(topicPerformance)
      .map(([topic, data]) => ({
        topic,
        percentage: data.percentage,
      }))
      .sort((a, b) => b.percentage - a.percentage)

    // Get strengths (top 3)
    return topicScores.slice(0, 3).map((item) => item.topic)
  }

  const calculateTopWeaknesses = (resultData: TestResult, testData: TestWithQuestions) => {
    const topicPerformance = calculateTopicPerformance(resultData, testData)

    // Sort by percentage
    const topicScores = Object.entries(topicPerformance)
      .map(([topic, data]) => ({
        topic,
        percentage: data.percentage,
      }))
      .sort((a, b) => a.percentage - b.percentage)

    // Get weaknesses (bottom 3)
    return topicScores.slice(0, 3).map((item) => item.topic)
  }

  if (loading) {
    return (
      <DashboardLayout requiredRole="user">
        <div className="flex justify-center py-12">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-purple-200 border-t-purple-700"></div>
        </div>
      </DashboardLayout>
    )
  }

  if (error || !result || !test) {
    return (
      <DashboardLayout requiredRole="user">
        <div className="space-y-4">
          <h1 className="text-3xl font-bold text-purple-800">Test Results</h1>
          <Card className="border-purple-200">
            <CardContent className="py-10 text-center">
              <p className="text-gray-500">{error || "Failed to load test results"}</p>
              <Button asChild className="mt-4">
                <Link href="/user/history">View All Results</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </DashboardLayout>
    )
  }

  const performance = calculatePerformanceByDifficulty()

  return (
    <DashboardLayout requiredRole="user">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <h1 className="text-3xl font-bold text-purple-800">{test.title} Results</h1>
          <div className="flex gap-2">
            <Button asChild variant="outline" className="border-purple-200 text-purple-700">
              <Link href="/user/dashboard">
                <Home className="mr-2 h-4 w-4" />
                Dashboard
              </Link>
            </Button>
            <Button variant="outline" className="border-purple-200 text-purple-700">
              <Download className="mr-2 h-4 w-4" />
              Download Report
            </Button>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="border-purple-200">
            <CardHeader>
              <CardTitle className="text-xl text-purple-800">Score Overview</CardTitle>
              <CardDescription>Your performance in this test</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col items-center">
                <div className="relative flex h-32 w-32 items-center justify-center rounded-full border-8 border-purple-100">
                  <div
                    className="absolute inset-0 rounded-full border-8 border-purple-500"
                    style={{
                      clipPath: `polygon(0 0, 100% 0, 100% 100%, 0% 100%)`,
                      clipPath: `path('M 50,50 m 0,-42 a 42,42 0 1 1 0,84 a 42,42 0 1 1 0,-84')`,
                      maskImage: `conic-gradient(#000 ${result.score}%, transparent ${result.score}%)`,
                      WebkitMaskImage: `conic-gradient(#000 ${result.score}%, transparent ${result.score}%)`,
                    }}
                  ></div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-800">{result.score}%</div>
                    <div className="text-xs text-gray-500">Score</div>
                  </div>
                </div>
                <div className="mt-4 text-center">
                  <p className="text-sm text-gray-600">
                    {
                      Object.values(result.answers).filter(
                        (answer, index) => answer === test.questions[index]?.correct_answer,
                      ).length
                    }{" "}
                    correct out of {test.questions.length} questions
                  </p>
                  <p className="text-xs text-gray-500">
                    Completed on {formatDate(result.completed_at)} • Time taken: {formatTime(result.time_taken)}
                  </p>
                </div>
              </div>

              {performance && (
                <div className="space-y-3">
                  <div>
                    <div className="mb-1 flex justify-between text-sm">
                      <span>
                        Easy ({performance.easy.correct}/{performance.easy.total})
                      </span>
                      <span>
                        {performance.easy.total > 0
                          ? `${Math.round((performance.easy.correct / performance.easy.total) * 100)}%`
                          : "N/A"}
                      </span>
                    </div>
                    <Progress
                      value={performance.easy.total > 0 ? (performance.easy.correct / performance.easy.total) * 100 : 0}
                      className="h-2 bg-purple-100"
                      indicatorClassName="bg-green-500"
                    />
                  </div>
                  <div>
                    <div className="mb-1 flex justify-between text-sm">
                      <span>
                        Intermediate ({performance.intermediate.correct}/{performance.intermediate.total})
                      </span>
                      <span>
                        {performance.intermediate.total > 0
                          ? `${Math.round((performance.intermediate.correct / performance.intermediate.total) * 100)}%`
                          : "N/A"}
                      </span>
                    </div>
                    <Progress
                      value={
                        performance.intermediate.total > 0
                          ? (performance.intermediate.correct / performance.intermediate.total) * 100
                          : 0
                      }
                      className="h-2 bg-purple-100"
                      indicatorClassName="bg-blue-500"
                    />
                  </div>
                  <div>
                    <div className="mb-1 flex justify-between text-sm">
                      <span>
                        Hard ({performance.hard.correct}/{performance.hard.total})
                      </span>
                      <span>
                        {performance.hard.total > 0
                          ? `${Math.round((performance.hard.correct / performance.hard.total) * 100)}%`
                          : "N/A"}
                      </span>
                    </div>
                    <Progress
                      value={performance.hard.total > 0 ? (performance.hard.correct / performance.hard.total) * 100 : 0}
                      className="h-2 bg-purple-100"
                      indicatorClassName="bg-purple-500"
                    />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-purple-200">
            <CardHeader>
              <CardTitle className="text-xl text-purple-800">Performance Analysis</CardTitle>
              <CardDescription>Strengths, weaknesses, and recommendations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="mb-2 font-medium text-purple-800 flex items-center">
                  <Award className="mr-2 h-4 w-4 text-green-600" />
                  Strengths
                </h3>
                <ul className="ml-6 list-disc space-y-2 text-sm">
                  {analysis?.strengths && analysis.strengths.length > 0 ? (
                    analysis.strengths.map((strength, index) => (
                      <li key={index}>
                        <span className="font-medium">{strength.topic}:</span> {strength.details}
                      </li>
                    ))
                  ) : (
                    <li>Not enough data to determine strengths</li>
                  )}
                </ul>
              </div>

              <div>
                <h3 className="mb-2 font-medium text-purple-800 flex items-center">
                  <X className="mr-2 h-4 w-4 text-red-600" />
                  Areas for Improvement
                </h3>
                <ul className="ml-6 list-disc space-y-2 text-sm">
                  {analysis?.weaknesses && analysis.weaknesses.length > 0 ? (
                    analysis.weaknesses.map((weakness, index) => (
                      <li key={index}>
                        <span className="font-medium">{weakness.topic}:</span> {weakness.details}
                      </li>
                    ))
                  ) : (
                    <li>Not enough data to determine areas for improvement</li>
                  )}
                </ul>
              </div>

              <div>
                <h3 className="mb-2 font-medium text-purple-800 flex items-center">
                  <FileText className="mr-2 h-4 w-4 text-purple-600" />
                  Recommendations
                </h3>
                <ul className="ml-6 list-disc space-y-1 text-sm">
                  {analysis?.recommendations && analysis.recommendations.length > 0 ? (
                    analysis.recommendations.map((recommendation, index) => <li key={index}>{recommendation}</li>)
                  ) : (
                    <>
                      <li>Focus on improving your understanding of topics with lower scores</li>
                      <li>Review explanations for questions you answered incorrectly</li>
                      <li>Take more tests to improve your performance</li>
                    </>
                  )}
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all">All Questions</TabsTrigger>
            <TabsTrigger value="correct">
              Correct (
              {
                Object.values(result.answers).filter(
                  (answer, index) => answer === test.questions[index]?.correct_answer,
                ).length
              }
              )
            </TabsTrigger>
            <TabsTrigger value="incorrect">
              Incorrect (
              {
                Object.values(result.answers).filter(
                  (answer, index) => answer !== test.questions[index]?.correct_answer,
                ).length
              }
              )
            </TabsTrigger>
          </TabsList>

          {["all", "correct", "incorrect"].map((tab) => (
            <TabsContent key={tab} value={tab} className="space-y-4 mt-6">
              {test.questions
                .filter((question) => {
                  const userAnswer = result.answers[question.id]
                  const isCorrect = userAnswer === question.correct_answer

                  if (tab === "all") return true
                  if (tab === "correct") return isCorrect
                  if (tab === "incorrect") return !isCorrect
                  return true
                })
                .map((question, index) => {
                  const userAnswer = result.answers[question.id]
                  const isCorrect = userAnswer === question.correct_answer

                  return (
                    <Card key={question.id} className="border-purple-200">
                      <CardHeader className="pb-2">
                        <div
                          className="flex cursor-pointer items-center justify-between"
                          onClick={() => toggleQuestion(question.id)}
                        >
                          <CardTitle className="text-base text-purple-800 flex items-center">
                            <span className="mr-2">{index + 1}.</span>
                            {question.text}
                            {isCorrect ? (
                              <Check className="ml-2 h-4 w-4 text-green-600" />
                            ) : (
                              <X className="ml-2 h-4 w-4 text-red-600" />
                            )}
                          </CardTitle>
                          {isQuestionExpanded(question.id) ? (
                            <ChevronUp className="h-5 w-5 text-purple-600" />
                          ) : (
                            <ChevronDown className="h-5 w-5 text-purple-600" />
                          )}
                        </div>
                        <CardDescription>
                          <span className="capitalize">{question.difficulty}</span> difficulty •{" "}
                          {question.topic || test.topic}
                        </CardDescription>
                      </CardHeader>
                      {isQuestionExpanded(question.id) && (
                        <CardContent>
                          <div className="space-y-3">
                            {question.options.map((option, optionIndex) => (
                              <div
                                key={optionIndex}
                                className={`flex items-center rounded-md border p-3 ${
                                  optionIndex === question.correct_answer
                                    ? "border-green-500 bg-green-50"
                                    : optionIndex === userAnswer && optionIndex !== question.correct_answer
                                      ? "border-red-500 bg-red-50"
                                      : "border-gray-200"
                                }`}
                              >
                                <div className="mr-3 flex h-5 w-5 items-center justify-center rounded-full border border-gray-300">
                                  {optionIndex === question.correct_answer ? (
                                    <Check className="h-3 w-3 text-green-600" />
                                  ) : optionIndex === userAnswer ? (
                                    <X className="h-3 w-3 text-red-600" />
                                  ) : (
                                    <span className="h-2 w-2 rounded-full bg-white"></span>
                                  )}
                                </div>
                                <div className="text-sm">{option}</div>
                              </div>
                            ))}
                            {question.explanation && (
                              <div className="mt-4 rounded-md bg-purple-50 p-3 text-sm">
                                <p className="font-medium text-purple-800">Explanation:</p>
                                <p className="mt-1 text-gray-700">{question.explanation}</p>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      )}
                    </Card>
                  )
                })}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
