"use client"

import Link from "next/link"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { AlertCircle, ArrowLeft, ArrowRight, Clock, Send } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { getTestWithQuestions } from "@/app/actions/tests"
import { submitTestResult } from "@/app/actions/results"
import { supabase } from "@/lib/supabase/client"
import type { TestWithQuestions } from "@/lib/types"

export default function TakeTest({ params }: { params: { id: string } }) {
  const router = useRouter()
  const testId = params.id

  const [test, setTest] = useState<TestWithQuestions | null>(null)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<(number | null)[]>([])
  const [timeLeft, setTimeLeft] = useState(3600) // Default 60 minutes in seconds
  const [isSubmitDialogOpen, setIsSubmitDialogOpen] = useState(false)
  const [isTimeUpDialogOpen, setIsTimeUpDialogOpen] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [startTime] = useState(new Date().toISOString())
  const [userId, setUserId] = useState<string | null>(null)

  useEffect(() => {
    // Get the current user ID from cookies
    const cookies = document.cookie.split("; ")
    const userIdCookie = cookies.find((cookie) => cookie.startsWith("user_id="))
    const currentUserId = userIdCookie ? userIdCookie.split("=")[1] : null

    if (!currentUserId) {
      setError("User ID not found. Please log in again.")
      setLoading(false)
      return
    }

    setUserId(currentUserId)

    const fetchTest = async () => {
      try {
        const testData = await getTestWithQuestions(testId)
        if (!testData) {
          setError("Test not found or you don't have access to it")
          return
        }

        // Check if the test is active or published
        if (testData.status !== "active" && testData.status !== "published") {
          setError("This test is not currently available")
          return
        }

        setTest(testData)
        setTimeLeft(testData.duration * 60) // Convert minutes to seconds
        setAnswers(new Array(testData.questions.length).fill(null))

        // Check if the test is already assigned to the user
        const { data: existingAssignment, error: checkError } = await supabase
          .from("user_tests")
          .select("id, status")
          .eq("user_id", currentUserId)
          .eq("test_id", testId)
          .single()

        if (checkError && checkError.code !== "PGRST116") {
          // PGRST116 is the error code for "no rows returned"
          console.error("Error checking existing assignment:", checkError)
        }

        // If the test is not already assigned or has a status other than "completed", assign it
        if (!existingAssignment) {
          const { error: assignError } = await supabase.from("user_tests").insert([
            {
              user_id: currentUserId,
              test_id: testId,
              assigned_at: new Date().toISOString(),
              status: "started",
            },
          ])

          if (assignError) {
            console.error("Error assigning test:", assignError)
          }
        } else if (existingAssignment.status === "assigned") {
          // Update the status to "started"
          const { error: updateError } = await supabase
            .from("user_tests")
            .update({ status: "started" })
            .eq("id", existingAssignment.id)

          if (updateError) {
            console.error("Error updating test status:", updateError)
          }
        } else if (existingAssignment.status === "completed") {
          setError("You have already completed this test")
          return
        }
      } catch (err) {
        console.error("Error fetching test:", err)
        setError("Failed to load test")
      } finally {
        setLoading(false)
      }
    }

    fetchTest()
  }, [testId])

  // Rest of the component remains the same...
  // Timer countdown
  useEffect(() => {
    if (!test) return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          setIsTimeUpDialogOpen(true)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [test])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const handleAnswerSelect = (questionIndex: number, optionIndex: number) => {
    const newAnswers = [...answers]
    newAnswers[questionIndex] = optionIndex
    setAnswers(newAnswers)
  }

  const handleNext = () => {
    if (test && currentQuestion < test.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const handleSubmit = async () => {
    if (!test || !userId) return

    try {
      // Convert answers to a record of question ID to answer index
      const answersRecord: Record<string, number> = {}
      test.questions.forEach((question, index) => {
        if (answers[index] !== null) {
          answersRecord[question.id] = answers[index] as number
        }
      })

      const formData = new FormData()
      formData.append("testId", testId)
      formData.append("answers", JSON.stringify(answersRecord))
      formData.append("timeTaken", String(test.duration * 60 - timeLeft))
      formData.append("startedAt", startTime)

      const result = await submitTestResult(formData)

      if (result.error) {
        console.error("Error submitting test:", result.error)
        alert("Failed to submit test: " + result.error)
        return
      }

      // Redirect to results page
      router.push(`/user/test-results/${testId}`)
    } catch (err) {
      console.error("Error submitting test:", err)
      alert("An error occurred while submitting the test")
    }
  }

  if (loading) {
    return (
      <DashboardLayout requiredRole="user">
        <div className="flex justify-center py-12">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-purple-200 border-t-purple-700"></div>
        </div>
      </DashboardLayout>
    )
  }

  if (error || !test) {
    return (
      <DashboardLayout requiredRole="user">
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error || "Test not found"}</AlertDescription>
        </Alert>
        <Button asChild className="mt-4">
          <Link href="/user/active-tests">Back to Active Tests</Link>
        </Button>
      </DashboardLayout>
    )
  }

  const progress = ((currentQuestion + 1) / test.questions.length) * 100
  const answeredCount = answers.filter((a) => a !== null).length
  const question = test.questions[currentQuestion]

  return (
    <DashboardLayout requiredRole="user">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-purple-800">{test.title}</h1>
          <div className="flex items-center gap-2 text-purple-800">
            <Clock className="h-5 w-5" />
            <span className="font-mono text-lg font-medium">{formatTime(timeLeft)}</span>
          </div>
        </div>

        <div className="flex items-center justify-between text-sm">
          <div>
            Question {currentQuestion + 1} of {test.questions.length}
          </div>
          <div>
            {answeredCount} of {test.questions.length} answered
          </div>
        </div>

        <Progress value={progress} className="h-2 bg-purple-100" indicatorClassName="bg-purple-600" />

        <Card className="border-purple-200">
          <CardHeader>
            <CardTitle className="text-lg text-purple-800">
              {currentQuestion + 1}. {question.text}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {question.options.map((option, index) => (
                <div
                  key={index}
                  className={`flex items-center rounded-md border p-3 cursor-pointer transition-colors ${
                    answers[currentQuestion] === index
                      ? "border-purple-500 bg-purple-50"
                      : "border-gray-200 hover:border-purple-200 hover:bg-purple-50"
                  }`}
                  onClick={() => handleAnswerSelect(currentQuestion, index)}
                >
                  <div
                    className={`mr-3 flex h-5 w-5 items-center justify-center rounded-full border ${
                      answers[currentQuestion] === index
                        ? "border-purple-500 bg-purple-500 text-white"
                        : "border-gray-300"
                    }`}
                  >
                    {answers[currentQuestion] === index && <div className="h-2 w-2 rounded-full bg-white" />}
                  </div>
                  <span>{option}</span>
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button
              variant="outline"
              onClick={handlePrevious}
              disabled={currentQuestion === 0}
              className="border-purple-200 text-purple-700"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Previous
            </Button>

            <div className="flex gap-2">
              {currentQuestion === test.questions.length - 1 ? (
                <Button
                  onClick={() => setIsSubmitDialogOpen(true)}
                  className="bg-purple-700 hover:bg-purple-800 text-white"
                >
                  <Send className="mr-2 h-4 w-4" />
                  Submit Test
                </Button>
              ) : (
                <Button onClick={handleNext} className="bg-purple-700 hover:bg-purple-800 text-white">
                  <ArrowRight className="mr-2 h-4 w-4" />
                  Next
                </Button>
              )}
            </div>
          </CardFooter>
        </Card>

        {answeredCount < test.questions.length && (
          <Alert className="bg-amber-50 border-amber-200">
            <AlertCircle className="h-4 w-4 text-amber-600" />
            <AlertDescription className="text-amber-800">
              You have {test.questions.length - answeredCount} unanswered questions. Make sure to answer all questions
              before submitting.
            </AlertDescription>
          </Alert>
        )}
      </div>

      <AlertDialog open={isSubmitDialogOpen} onOpenChange={setIsSubmitDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Submit Test</AlertDialogTitle>
            <AlertDialogDescription>
              {answeredCount < test.questions.length ? (
                <>
                  You have {test.questions.length - answeredCount} unanswered questions. Are you sure you want to submit
                  the test? You won't be able to change your answers after submission.
                </>
              ) : (
                <>
                  Are you sure you want to submit the test? You won't be able to change your answers after submission.
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-purple-200 text-purple-700">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleSubmit} className="bg-purple-700 hover:bg-purple-800 text-white">
              Submit Test
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={isTimeUpDialogOpen} onOpenChange={setIsTimeUpDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Time's Up!</AlertDialogTitle>
            <AlertDialogDescription>
              Your time for this test has expired. Your answers will be automatically submitted.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={handleSubmit} className="bg-purple-700 hover:bg-purple-800 text-white">
              View Results
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  )
}
