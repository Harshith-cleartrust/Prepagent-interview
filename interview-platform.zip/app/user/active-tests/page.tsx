"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Clock, FileText, Calendar } from "lucide-react"
import Link from "next/link"
import { supabase } from "@/lib/supabase/client"
import type { Test } from "@/lib/types"

interface AssignedTest extends Test {
  due_date?: string | null
  user_test_id?: string
}

export default function ActiveTests() {
  const [tests, setTests] = useState<AssignedTest[]>([])
  const [publishedTests, setPublishedTests] = useState<Test[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchTests = async () => {
      try {
        // Get the current user ID from cookies
        const cookies = document.cookie.split("; ")
        const userIdCookie = cookies.find((cookie) => cookie.startsWith("user_id="))
        const userId = userIdCookie ? userIdCookie.split("=")[1] : null

        if (!userId) {
          console.error("User ID not found in cookies")
          setLoading(false)
          return
        }

        // Fetch tests assigned to the user
        const { data: userTests, error: userTestsError } = await supabase
          .from("user_tests")
          .select(`
            id,
            test_id,
            due_date,
            status,
            tests (
              id,
              title,
              description,
              topic,
              duration,
              status,
              created_at
            )
          `)
          .eq("user_id", userId)
          .eq("status", "assigned")
          .order("due_date", { ascending: true })

        if (userTestsError) {
          console.error("Error fetching user tests:", userTestsError)
          setLoading(false)
          return
        }

        // Fetch published tests that are available to all users
        const { data: allPublishedTests, error: publishedError } = await supabase
          .from("tests")
          .select("*")
          .eq("status", "published")
          .order("created_at", { ascending: false })

        if (publishedError) {
          console.error("Error fetching published tests:", publishedError)
        } else {
          // Filter out tests that are already assigned to the user
          const assignedTestIds = userTests.filter((ut) => ut.tests).map((ut) => ut.tests?.id)

          const filteredPublishedTests = allPublishedTests.filter((test) => !assignedTestIds.includes(test.id))

          setPublishedTests(filteredPublishedTests)
        }

        // Transform the data to match the expected format
        const transformedTests = userTests
          .filter((userTest) => userTest.tests) // Filter out any null tests
          .map((userTest) => ({
            ...userTest.tests,
            due_date: userTest.due_date,
            user_test_id: userTest.id,
          })) as AssignedTest[]

        setTests(transformedTests)
      } catch (error) {
        console.error("Error fetching active tests:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchTests()
  }, [])

  const formatDueDate = (dateString: string | null | undefined) => {
    if (!dateString) return "No due date"

    const dueDate = new Date(dateString)
    const now = new Date()
    const diffDays = Math.floor((dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))

    if (diffDays < 0) return "Overdue"
    if (diffDays === 0) return "Today"
    if (diffDays === 1) return "Tomorrow"
    if (diffDays < 7) return `In ${diffDays} days`
    return dueDate.toLocaleDateString()
  }

  const getStatusBadgeClass = (dueDate: string | null | undefined) => {
    if (!dueDate) return "bg-gray-100 text-gray-800"

    const date = dueDate ? new Date(dueDate) : null
    const now = new Date()

    if (!date) return "bg-gray-100 text-gray-800"

    if (date < now) return "bg-red-100 text-red-800"

    const diffDays = Math.floor((date.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))

    if (diffDays <= 2) return "bg-yellow-100 text-yellow-800"
    return "bg-green-100 text-green-800"
  }

  if (loading) {
    return (
      <DashboardLayout requiredRole="user">
        <div className="flex justify-center py-12">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-purple-200 border-t-purple-700"></div>
        </div>
      </DashboardLayout>
    )
  }

  const allTests = [...tests, ...publishedTests]

  return (
    <DashboardLayout requiredRole="user">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-3xl font-bold text-purple-800">Active Tests</h1>
        </div>

        <Tabs defaultValue="all">
          <TabsList className="mb-4">
            <TabsTrigger value="all">All Tests ({allTests.length})</TabsTrigger>
            <TabsTrigger value="assigned">Assigned ({tests.length})</TabsTrigger>
            <TabsTrigger value="published">Published ({publishedTests.length})</TabsTrigger>
            <TabsTrigger value="overdue">Overdue</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            {allTests.length > 0 ? (
              allTests.map((test) => (
                <Card key={test.id} className="border-purple-200">
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-xl text-purple-800">{test.title}</CardTitle>
                      {"due_date" in test ? (
                        <div
                          className={`rounded-full px-3 py-1 text-xs font-medium ${getStatusBadgeClass(test.due_date)}`}
                        >
                          {formatDueDate(test.due_date)}
                        </div>
                      ) : (
                        <div className="rounded-full bg-purple-100 px-3 py-1 text-xs font-medium text-purple-800">
                          Published
                        </div>
                      )}
                    </div>
                    <CardDescription>{test.description || "No description provided"}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-4 text-sm text-gray-500">
                      <div className="flex items-center">
                        <Clock className="mr-1 h-4 w-4 text-purple-500" />
                        {test.duration} minutes
                      </div>
                      <div className="flex items-center">
                        <FileText className="mr-1 h-4 w-4 text-purple-500" />
                        {test.topic}
                      </div>
                      <div className="flex items-center">
                        <Calendar className="mr-1 h-4 w-4 text-purple-500" />
                        {new Date(test.created_at).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="mt-4">
                      <Button asChild className="bg-purple-700 hover:bg-purple-800 text-white">
                        <Link href={`/user/take-test/${test.id}`}>Start Test</Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="rounded-lg border border-dashed border-gray-300 p-8 text-center">
                <h3 className="text-lg font-medium text-gray-900">No active tests</h3>
                <p className="mt-1 text-sm text-gray-500">
                  You don't have any active tests assigned to you at the moment.
                </p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="assigned" className="space-y-4">
            {tests.length > 0 ? (
              tests.map((test) => (
                <Card key={test.id} className="border-purple-200">
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-xl text-purple-800">{test.title}</CardTitle>
                      <div
                        className={`rounded-full px-3 py-1 text-xs font-medium ${getStatusBadgeClass(test.due_date)}`}
                      >
                        {formatDueDate(test.due_date)}
                      </div>
                    </div>
                    <CardDescription>{test.description || "No description provided"}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-4 text-sm text-gray-500">
                      <div className="flex items-center">
                        <Clock className="mr-1 h-4 w-4 text-purple-500" />
                        {test.duration} minutes
                      </div>
                      <div className="flex items-center">
                        <FileText className="mr-1 h-4 w-4 text-purple-500" />
                        {test.topic}
                      </div>
                      <div className="flex items-center">
                        <Calendar className="mr-1 h-4 w-4 text-purple-500" />
                        {new Date(test.created_at).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="mt-4">
                      <Button asChild className="bg-purple-700 hover:bg-purple-800 text-white">
                        <Link href={`/user/take-test/${test.id}`}>Start Test</Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="rounded-lg border border-dashed border-gray-300 p-8 text-center">
                <h3 className="text-lg font-medium text-gray-900">No assigned tests</h3>
                <p className="mt-1 text-sm text-gray-500">
                  You don't have any tests specifically assigned to you at the moment.
                </p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="published" className="space-y-4">
            {publishedTests.length > 0 ? (
              publishedTests.map((test) => (
                <Card key={test.id} className="border-purple-200">
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-xl text-purple-800">{test.title}</CardTitle>
                      <div className="rounded-full bg-purple-100 px-3 py-1 text-xs font-medium text-purple-800">
                        Published
                      </div>
                    </div>
                    <CardDescription>{test.description || "No description provided"}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-4 text-sm text-gray-500">
                      <div className="flex items-center">
                        <Clock className="mr-1 h-4 w-4 text-purple-500" />
                        {test.duration} minutes
                      </div>
                      <div className="flex items-center">
                        <FileText className="mr-1 h-4 w-4 text-purple-500" />
                        {test.topic}
                      </div>
                      <div className="flex items-center">
                        <Calendar className="mr-1 h-4 w-4 text-purple-500" />
                        {new Date(test.created_at).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="mt-4">
                      <Button asChild className="bg-purple-700 hover:bg-purple-800 text-white">
                        <Link href={`/user/take-test/${test.id}`}>Start Test</Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="rounded-lg border border-dashed border-gray-300 p-8 text-center">
                <h3 className="text-lg font-medium text-gray-900">No published tests</h3>
                <p className="mt-1 text-sm text-gray-500">There are no published tests available at the moment.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="overdue" className="space-y-4">
            {tests.filter((test) => {
              if (!test.due_date) return false
              const dueDate = new Date(test.due_date)
              const now = new Date()
              return dueDate < now
            }).length > 0 ? (
              tests
                .filter((test) => {
                  if (!test.due_date) return false
                  const dueDate = new Date(test.due_date)
                  const now = new Date()
                  return dueDate < now
                })
                .map((test) => (
                  <Card key={test.id} className="border-purple-200">
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-xl text-purple-800">{test.title}</CardTitle>
                        <div className="rounded-full bg-red-100 px-3 py-1 text-xs font-medium text-red-800">
                          Overdue
                        </div>
                      </div>
                      <CardDescription>{test.description || "No description provided"}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-4 text-sm text-gray-500">
                        <div className="flex items-center">
                          <Clock className="mr-1 h-4 w-4 text-purple-500" />
                          {test.duration} minutes
                        </div>
                        <div className="flex items-center">
                          <FileText className="mr-1 h-4 w-4 text-purple-500" />
                          {test.topic}
                        </div>
                        <div className="flex items-center">
                          <Calendar className="mr-1 h-4 w-4 text-purple-500" />
                          {new Date(test.created_at).toLocaleDateString()}
                        </div>
                      </div>
                      <div className="mt-4">
                        <Button asChild className="bg-purple-700 hover:bg-purple-800 text-white">
                          <Link href={`/user/take-test/${test.id}`}>Start Test</Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
            ) : (
              <div className="rounded-lg border border-dashed border-gray-300 p-8 text-center">
                <h3 className="text-lg font-medium text-gray-900">No overdue tests</h3>
                <p className="mt-1 text-sm text-gray-500">
                  You don't have any overdue tests. Great job staying on top of your assignments!
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
