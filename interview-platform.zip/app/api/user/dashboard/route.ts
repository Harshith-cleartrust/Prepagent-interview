import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { supabaseServer } from "@/lib/supabase/server"

export async function GET() {
  const userId = cookies().get("user_id")?.value

  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    // Get completed tests count
    const { count: testsCompleted, error: testsError } = await supabaseServer
      .from("test_results")
      .select("*", { count: "exact", head: true })
      .eq("user_id", userId)

    if (testsError) {
      console.error("Error fetching completed tests:", testsError)
      return NextResponse.json({ error: "Failed to fetch completed tests" }, { status: 500 })
    }

    // Get average score
    const { data: scores, error: scoresError } = await supabaseServer
      .from("test_results")
      .select("score")
      .eq("user_id", userId)

    if (scoresError) {
      console.error("Error fetching scores:", scoresError)
      return NextResponse.json({ error: "Failed to fetch scores" }, { status: 500 })
    }

    const averageScore =
      scores.length > 0 ? Math.round(scores.reduce((sum, result) => sum + result.score, 0) / scores.length) : 0

    // Get active tests
    const { data: activeTests, error: activeError } = await supabaseServer
      .from("user_tests")
      .select(`
        id,
        due_date,
        tests (
          id,
          title,
          duration,
          questions (
            id
          )
        )
      `)
      .eq("user_id", userId)
      .eq("status", "assigned")
      .order("due_date", { ascending: true })

    if (activeError) {
      console.error("Error fetching active tests:", activeError)
      return NextResponse.json({ error: "Failed to fetch active tests" }, { status: 500 })
    }

    // Get recent results
    const { data: recentResults, error: recentError } = await supabaseServer
      .from("test_results")
      .select(`
        id,
        score,
        completed_at,
        tests (
          id,
          title
        )
      `)
      .eq("user_id", userId)
      .order("completed_at", { ascending: false })
      .limit(2)

    if (recentError) {
      console.error("Error fetching recent results:", recentError)
      return NextResponse.json({ error: "Failed to fetch recent results" }, { status: 500 })
    }

    // Format the data
    const formattedActiveTests = activeTests.map((test) => {
      const dueDate = test.due_date ? new Date(test.due_date) : null
      const now = new Date()
      const diffDays = dueDate ? Math.ceil((dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)) : null

      let dueDateText = "No due date"
      if (diffDays !== null) {
        if (diffDays < 0) {
          dueDateText = "Overdue"
        } else if (diffDays === 0) {
          dueDateText = "Today"
        } else if (diffDays === 1) {
          dueDateText = "Tomorrow"
        } else {
          dueDateText = `In ${diffDays} days`
        }
      }

      return {
        id: test.tests?.id,
        title: test.tests?.title,
        duration: `${test.tests?.duration} min`,
        questions: test.tests?.questions?.length || 0,
        dueDate: dueDateText,
        status: diffDays !== null && diffDays <= 1 ? "urgent" : "upcoming",
      }
    })

    const formattedRecentResults = recentResults.map((result) => {
      const completedDate = new Date(result.completed_at)
      const now = new Date()
      const diffDays = Math.ceil((now.getTime() - completedDate.getTime()) / (1000 * 60 * 60 * 24))

      return {
        id: result.id,
        title: result.tests?.title,
        score: result.score,
        completedAt: diffDays === 0 ? "Today" : `${diffDays} days ago`,
      }
    })

    return NextResponse.json({
      testsCompleted,
      averageScore,
      activeTests: formattedActiveTests,
      recentResults: formattedRecentResults,
    })
  } catch (error) {
    console.error("Error fetching data:", error)
    return NextResponse.json({ error: "Failed to fetch data" }, { status: 500 })
  }
}
