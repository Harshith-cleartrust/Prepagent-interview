import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { supabaseServer } from "@/lib/supabase/server"

export async function GET(request: Request) {
  const role = cookies().get("role")?.value
  const userId = cookies().get("user_id")?.value

  // Only admins can access this endpoint
  if (role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  // Get the period from the query parameters
  const url = new URL(request.url)
  const period = url.searchParams.get("period") || "last6months"

  try {
    // Get date range based on period
    const endDate = new Date()
    let startDate = new Date()

    switch (period) {
      case "last30days":
        startDate.setDate(startDate.getDate() - 30)
        break
      case "last3months":
        startDate.setMonth(startDate.getMonth() - 3)
        break
      case "last6months":
        startDate.setMonth(startDate.getMonth() - 6)
        break
      case "lastyear":
        startDate.setFullYear(startDate.getFullYear() - 1)
        break
      case "alltime":
        startDate = new Date(0) // Beginning of time
        break
      default:
        startDate.setMonth(startDate.getMonth() - 6)
    }

    // Get tests created by this admin
    const { data: tests, error: testsError } = await supabaseServer
      .from("tests")
      .select("id, title, created_at")
      .eq("created_by", userId)
      .gte("created_at", startDate.toISOString())
      .lte("created_at", endDate.toISOString())
      .order("created_at", { ascending: true })

    if (testsError) {
      console.error("Error fetching tests:", testsError)
      return NextResponse.json({ error: "Failed to fetch tests" }, { status: 500 })
    }

    if (!tests || tests.length === 0) {
      // Return empty analytics data
      return NextResponse.json({
        performanceData: [],
        participationData: [],
        topPerformers: [],
        testPerformance: [],
        scoreChange: "0%",
        currentAverage: "0%",
        participationChange: "0%",
        totalParticipants: 0,
        maxParticipants: 1,
        userPerformance: null,
        testAnalysis: null,
      })
    }

    // Get test results for these tests
    const testIds = tests.map((test) => test.id)
    const { data: results, error: resultsError } = await supabaseServer
      .from("test_results")
      .select(`
        id, 
        score, 
        completed_at,
        test_id,
        user_id,
        users (
          id, 
          username
        )
      `)
      .in("test_id", testIds)
      .order("completed_at", { ascending: true })

    if (resultsError) {
      console.error("Error fetching results:", resultsError)
      return NextResponse.json({ error: "Failed to fetch results" }, { status: 500 })
    }

    // Process data for charts
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

    // Group results by month
    const resultsByMonth: Record<string, { scores: number[]; participants: Set<string> }> = {}

    results.forEach((result) => {
      const date = new Date(result.completed_at)
      const monthKey = `${months[date.getMonth()]} ${date.getFullYear()}`

      if (!resultsByMonth[monthKey]) {
        resultsByMonth[monthKey] = { scores: [], participants: new Set() }
      }

      resultsByMonth[monthKey].scores.push(result.score)
      resultsByMonth[monthKey].participants.add(result.user_id)
    })

    // Convert to arrays for charts
    const performanceData = Object.entries(resultsByMonth).map(([month, data]) => ({
      month,
      score: data.scores.reduce((sum, score) => sum + score, 0) / data.scores.length || 0,
    }))

    const participationData = Object.entries(resultsByMonth).map(([month, data]) => ({
      month,
      count: data.participants.size,
    }))

    // Calculate top performers
    const userScores: Record<string, { scores: number[]; name: string }> = {}

    results.forEach((result) => {
      const userId = result.user_id
      const username = result.users?.username || "Unknown"

      if (!userScores[userId]) {
        userScores[userId] = { scores: [], name: username }
      }

      userScores[userId].scores.push(result.score)
    })

    const topPerformers = Object.entries(userScores)
      .map(([userId, data]) => ({
        id: userId,
        name: data.name,
        score: `${Math.round(data.scores.reduce((sum, score) => sum + score, 0) / data.scores.length)}%`,
        tests: data.scores.length,
      }))
      .sort((a, b) => Number.parseInt(b.score) - Number.parseInt(a.score))
      .slice(0, 5)

    // Calculate test performance
    const testScores: Record<string, { scores: number[]; participants: Set<string>; name: string }> = {}

    results.forEach((result) => {
      const testId = result.test_id
      const test = tests.find((t) => t.id === testId)

      if (!test) return

      if (!testScores[testId]) {
        testScores[testId] = { scores: [], participants: new Set(), name: test.title }
      }

      testScores[testId].scores.push(result.score)
      testScores[testId].participants.add(result.user_id)
    })

    const testPerformance = Object.entries(testScores)
      .map(([testId, data]) => ({
        id: testId,
        name: data.name,
        avgScore: `${Math.round(data.scores.reduce((sum, score) => sum + score, 0) / data.scores.length)}%`,
        participants: data.participants.size,
      }))
      .sort((a, b) => Number.parseInt(b.avgScore) - Number.parseInt(a.avgScore))
      .slice(0, 5)

    // Calculate changes and totals
    const firstMonthScore = performanceData.length > 0 ? performanceData[0].score : 0
    const lastMonthScore = performanceData.length > 0 ? performanceData[performanceData.length - 1].score : 0
    const scoreChange =
      firstMonthScore > 0 ? `${Math.round(((lastMonthScore - firstMonthScore) / firstMonthScore) * 100)}%` : "0%"

    const totalParticipants = new Set(results.map((r) => r.user_id)).size
    const maxParticipants = Math.max(...participationData.map((d) => d.count), 1)

    const firstMonthParticipants = participationData.length > 0 ? participationData[0].count : 0
    const lastMonthParticipants =
      participationData.length > 0 ? participationData[participationData.length - 1].count : 0
    const participationChange =
      firstMonthParticipants > 0
        ? `${Math.round(((lastMonthParticipants - firstMonthParticipants) / firstMonthParticipants) * 100)}%`
        : "0%"

    return NextResponse.json({
      performanceData,
      participationData,
      topPerformers,
      testPerformance,
      scoreChange: scoreChange !== "0%" ? `+${scoreChange}` : scoreChange,
      currentAverage: `${Math.round(lastMonthScore)}%`,
      participationChange: participationChange !== "0%" ? `+${participationChange}` : participationChange,
      totalParticipants,
      maxParticipants,
      userPerformance: null, // Detailed user performance would be added here
      testAnalysis: null, // Detailed test analysis would be added here
    })
  } catch (error) {
    console.error("Error in analytics API:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
