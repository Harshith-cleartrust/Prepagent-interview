"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, Lock, Mail } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { login } from "@/app/actions/auth"

export default function Login() {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [redirecting, setRedirecting] = useState(false)
  const [redirectPath, setRedirectPath] = useState("")

  // Check if already logged in
  useEffect(() => {
    const cookies = document.cookie.split("; ")
    const roleCookie = cookies.find((cookie) => cookie.startsWith("role="))

    if (roleCookie) {
      const role = roleCookie.split("=")[1]
      if (role === "admin") {
        router.push("/admin/dashboard")
      } else if (role === "user") {
        router.push("/user/dashboard")
      }
    }
  }, [router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const formData = new FormData(e.target as HTMLFormElement)
      console.log("Submitting login form with email:", formData.get("email"))

      const result = await login(formData)

      if (result.error) {
        console.error("Login error:", result.error)
        setError(result.error)
        setLoading(false)
        return
      }

      if (result.success) {
        console.log("Login successful, redirecting based on role:", result.user.role)

        // Set cookies manually on client side as well to ensure they're available immediately
        document.cookie = `role=${result.user.role}; path=/; max-age=${60 * 60 * 24}`
        document.cookie = `username=${result.user.username}; path=/; max-age=${60 * 60 * 24}`
        document.cookie = `user_id=${result.user.id}; path=/; max-age=${60 * 60 * 24}`

        // Set redirecting state
        setRedirecting(true)

        // Determine redirect path
        const path = result.user.role === "admin" ? "/admin/dashboard" : "/user/dashboard"
        setRedirectPath(path)

        // Use a timeout to ensure cookies are set before redirect
        setTimeout(() => {
          router.push(path)
          // Force a hard navigation if needed
          setTimeout(() => {
            window.location.href = path
          }, 500)
        }, 100)
      }
    } catch (err) {
      console.error("Unexpected login error:", err)
      setError("An error occurred during login")
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-purple-50 to-purple-100 p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center text-purple-800">Login to SAMAJH</CardTitle>
          <CardDescription className="text-center">Enter your credentials to access your account</CardDescription>
        </CardHeader>
        <CardContent>
          {redirecting ? (
            <div className="text-center py-4">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-purple-200 border-t-purple-700 mb-4"></div>
              <p>Redirecting to {redirectPath}...</p>
              <p className="text-sm text-gray-500 mt-2">
                If you are not redirected automatically,
                <Link href={redirectPath} className="text-purple-700 hover:underline ml-1">
                  click here
                </Link>
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <Alert variant="destructive" className="mb-4">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              <div className="space-y-2">
                <Label htmlFor="email">Username or Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-purple-500" />
                  <Input
                    id="email"
                    name="email"
                    type="text"
                    placeholder="Enter your username or email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10 border-purple-200 focus:border-purple-500"
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-purple-500" />
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 border-purple-200 focus:border-purple-500"
                    required
                  />
                </div>
              </div>
              <Button type="submit" className="w-full bg-purple-700 hover:bg-purple-800 text-white" disabled={loading}>
                {loading ? "Logging in..." : "Login"}
              </Button>
            </form>
          )}
        </CardContent>
        <CardFooter className="flex flex-col space-y-2">
          <div className="text-center text-sm">
            Don&apos;t have an account?{" "}
            <Link href="/register" className="text-purple-700 hover:underline">
              Register
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
