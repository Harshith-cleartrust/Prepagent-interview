import { GEMINI_API_KEY } from "@/lib/constants"

// The base URL for the Gemini API
const GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"

// Types for analytics data
export interface PerformanceData {
  month: string
  score: number
}

export interface ParticipationData {
  month: string
  count: number
}

export interface TopPerformer {
  id: string
  name: string
  score: string
  tests: number
}

export interface TestPerformance {
  id: string
  name: string
  avgScore: string
  participants: number
}

export interface AnalyticsData {
  performanceData: PerformanceData[]
  participationData: ParticipationData[]
  topPerformers: TopPerformer[]
  testPerformance: TestPerformance[]
  scoreChange: string
  currentAverage: string
  participationChange: string
  totalParticipants: number
  maxParticipants: number
  userPerformance: any
  testAnalysis: any
}

export interface UserAnalytics {
  performanceData: PerformanceData[]
  topicPerformance: {
    topic: string
    score: number
    tests: number
  }[]
  skillGaps: {
    skill: string
    score: number
  }[]
  recommendations: string[]
  stats: {
    testsCompleted: number
    averageScore: number
    improvement: number
  }
  testResults: any[]
  aiInsights?: string
}

// Function to generate insights from test results using Gemini API
export async function generateInsights(data: any, prompt: string): Promise<string> {
  try {
    const response = await fetch(GEMINI_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": GEMINI_API_KEY,
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: `${prompt}\n\nData: ${JSON.stringify(data, null, 2)}`,
              },
            ],
          },
        ],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 2048,
        },
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      console.error("Gemini API error:", errorData)
      return "Failed to generate insights. Please try again later."
    }

    const result = await response.json()

    // Clean the response text to handle markdown formatting
    let text = result.candidates[0].content.parts[0].text

    // Remove markdown formatting symbols
    text = text.replace(/\*\*/g, "") // Remove bold markers
    text = text.replace(/\*/g, "") // Remove italic markers
    text = text.replace(/#+\s/g, "") // Remove heading markers
    text = text.replace(/```json|```/g, "") // Remove code blocks

    return text.trim()
  } catch (error) {
    console.error("Error generating insights:", error)
    return "An error occurred while generating insights."
  }
}

// Function to generate recommendations based on user performance
export async function generateRecommendations(
  topicPerformance: { topic: string; score: number; tests: number }[],
): Promise<string[]> {
  try {
    const prompt = `
      Based on the user's performance in different topics, provide 5 specific, actionable recommendations 
      to help them improve. Focus on the topics with the lowest scores, but also suggest ways to maintain 
      performance in stronger areas. Each recommendation should be concise (1-2 sentences) and specific.
      
      Format your response as a JSON array of strings, with each string being a recommendation.
      Do not include any explanations, markdown formatting, or additional text outside the JSON array.
      Do not wrap your response in code blocks or backticks.
    `

    const response = await fetch(GEMINI_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": GEMINI_API_KEY,
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: `${prompt}\n\nTopic Performance: ${JSON.stringify(topicPerformance, null, 2)}`,
              },
            ],
          },
        ],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 1024,
        },
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      console.error("Gemini API error:", errorData)
      return [
        "Focus on improving your understanding of topics with lower scores.",
        "Review explanations for questions you answered incorrectly.",
        "Take more tests to improve your performance.",
        "Consider studying additional resources for challenging topics.",
        "Practice regularly to maintain your skills.",
      ]
    }

    const result = await response.json()
    const text = result.candidates[0].content.parts[0].text

    try {
      // Clean the response text to handle markdown formatting
      let cleanedText = text.trim()

      // Remove markdown code block markers if present
      cleanedText = cleanedText.replace(/```json|```/g, "").trim()

      // Try to find a JSON array in the response
      const jsonMatch = cleanedText.match(/\[\s*".*"\s*\]/s)
      if (jsonMatch) {
        cleanedText = jsonMatch[0]
      }

      // Parse the JSON
      const recommendations = JSON.parse(cleanedText)

      if (Array.isArray(recommendations) && recommendations.length > 0) {
        return recommendations.slice(0, 5)
      }
    } catch (e) {
      console.error("Error parsing recommendations:", e)
      console.log("Raw response:", text)
    }

    // Fallback recommendations
    return [
      "Focus on improving your understanding of topics with lower scores.",
      "Review explanations for questions you answered incorrectly.",
      "Take more tests to improve your performance.",
      "Consider studying additional resources for challenging topics.",
      "Practice regularly to maintain your skills.",
    ]
  } catch (error) {
    console.error("Error generating recommendations:", error)
    return [
      "Focus on improving your understanding of topics with lower scores.",
      "Review explanations for questions you answered incorrectly.",
      "Take more tests to improve your performance.",
      "Consider studying additional resources for challenging topics.",
      "Practice regularly to maintain your skills.",
    ]
  }
}

// Function to analyze test results for admin dashboard
export async function analyzeTestResults(results: any[]): Promise<string> {
  const prompt = `
    Analyze the following test results data and provide insights for an admin dashboard.
    Focus on:
    1. Overall performance trends
    2. Identification of common areas of difficulty
    3. Suggestions for improving test content
    4. Any notable patterns in user performance
    
    Keep your analysis concise and actionable, with 3-5 key insights.
  `

  return generateInsights(results, prompt)
}

// Function to analyze user performance for personalized feedback
export async function analyzeUserPerformance(results: any[]): Promise<string> {
  const prompt = `
    Analyze the following test results for a single user and provide personalized feedback.
    Focus on:
    1. Strengths and weaknesses based on topic performance
    2. Progress over time
    3. Specific areas to focus on for improvement
    4. Positive reinforcement of achievements
    
    Format your response with clear sections for:
    - Strengths: List each strength with a brief explanation of why they're doing well in this area
    - Weaknesses: List each weakness with specific details about what they need to improve
    
    Keep your analysis encouraging, specific, and actionable, with 3-4 key insights.
  `

  return generateInsights(results, prompt)
}

// Function to analyze skill gaps based on test answers
export async function analyzeSkillGaps(testData: any): Promise<{ skill: string; score: number }[]> {
  try {
    // If we don't have detailed user answers, generate skill gaps from topic performance
    if (!testData.userAnswers || Object.keys(testData.userAnswers).length === 0) {
      // Generate skill gaps based on topic performance
      return testData.topicPerformance
        .filter((topic) => topic.score < 80)
        .map((topic) => ({
          skill: topic.topic,
          score: Math.round(100 - topic.score),
        }))
        .slice(0, 5)
    }

    const prompt = `
      Analyze the following test data and identify specific skill gaps based on the user's answers.
      For each skill gap, provide:
      1. The name of the skill
      2. A score representing the gap (higher score = bigger gap, on a scale of 0-100)
      
      Format your response as a JSON array of objects with "skill" and "score" properties.
      Example: [{"skill": "Problem Solving", "score": 75}, {"skill": "Technical Knowledge", "score": 60}]
      
      Do not include any explanations, markdown formatting, or additional text outside the JSON array.
      Do not wrap your response in code blocks or backticks.
    `

    const response = await fetch(GEMINI_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": GEMINI_API_KEY,
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: `${prompt}\n\nTest Data: ${JSON.stringify(testData, null, 2)}`,
              },
            ],
          },
        ],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 1024,
        },
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      console.error("Gemini API error:", errorData)
      return []
    }

    const result = await response.json()
    const text = result.candidates[0].content.parts[0].text

    try {
      // Clean the response text to handle markdown formatting
      let cleanedText = text.trim()

      // Remove markdown code block markers if present
      cleanedText = cleanedText.replace(/```json|```/g, "").trim()

      // Try to find a JSON array in the response
      const jsonMatch = cleanedText.match(/\[\s*\{.*\}\s*\]/s)
      if (jsonMatch) {
        cleanedText = jsonMatch[0]
      }

      // Parse the JSON
      const skillGaps = JSON.parse(cleanedText)

      if (Array.isArray(skillGaps) && skillGaps.length > 0) {
        return skillGaps.slice(0, 5)
      }
    } catch (e) {
      console.error("Error parsing skill gaps:", e)
      console.log("Raw response:", text)
    }

    return []
  } catch (error) {
    console.error("Error analyzing skill gaps:", error)
    return []
  }
}

// Function to get user performance data with AI-generated insights
export async function getUserAnalytics(): Promise<UserAnalytics> {
  // This would normally fetch from the database
  // For now, we'll return mock data with AI-generated insights

  const testResults = [
    {
      id: "1",
      test_id: "test1",
      score: 85,
      completed_at: "2023-04-15T14:30:00Z",
      test: {
        title: "JavaScript Fundamentals",
        topic: "JavaScript",
      },
    },
    {
      id: "2",
      test_id: "test2",
      score: 72,
      completed_at: "2023-05-10T09:45:00Z",
      test: {
        title: "React Components",
        topic: "React",
      },
    },
    {
      id: "3",
      test_id: "test3",
      score: 68,
      completed_at: "2023-06-05T16:20:00Z",
      test: {
        title: "State Management",
        topic: "React",
      },
    },
  ]

  const topicPerformance = [
    { topic: "JavaScript Fundamentals", score: 85, tests: 5 },
    { topic: "React Components", score: 72, tests: 3 },
    { topic: "State Management", score: 68, tests: 4 },
    { topic: "API Integration", score: 90, tests: 2 },
    { topic: "Testing", score: 62, tests: 3 },
  ]

  // Get skill gaps from AI analysis
  const skillGapsData = {
    testResults,
    topicPerformance,
    userAnswers: {
      q1: { correct: true, topic: "JavaScript", difficulty: "easy" },
      q2: { correct: false, topic: "JavaScript", difficulty: "hard" },
      q3: { correct: true, topic: "React", difficulty: "medium" },
      q4: { correct: false, topic: "React", difficulty: "hard" },
      q5: { correct: false, topic: "Testing", difficulty: "medium" },
    },
  }

  const skillGaps = await analyzeSkillGaps(skillGapsData)

  // Generate AI insights for the user
  const aiInsights = await analyzeUserPerformance(testResults)

  return {
    performanceData: [
      { month: "Jan", score: 65 },
      { month: "Feb", score: 68 },
      { month: "Mar", score: 72 },
      { month: "Apr", score: 75 },
      { month: "May", score: 80 },
      { month: "Jun", score: 78 },
    ],
    topicPerformance,
    skillGaps,
    recommendations: await generateRecommendations(topicPerformance),
    stats: {
      testsCompleted: 17,
      averageScore: 75,
      improvement: 8,
    },
    testResults,
    aiInsights,
  }
}
