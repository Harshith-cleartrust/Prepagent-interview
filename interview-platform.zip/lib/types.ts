export interface User {
  id: string
  username: string
  email: string
  role: "admin" | "user"
  created_at: string
  last_login: string | null
}

export interface Test {
  id: string
  title: string
  topic: string
  description: string | null
  duration: number
  created_by: string
  status: "draft" | "active" | "published" | "completed"
  created_at: string
  updated_at: string
}

export interface Question {
  id: string
  test_id: string
  text: string
  options: string[]
  correct_answer: number
  difficulty: "easy" | "intermediate" | "hard"
  explanation: string | null
  created_at: string
}

export interface UserTest {
  id: string
  user_id: string
  test_id: string
  assigned_at: string
  due_date: string | null
  status: "assigned" | "started" | "completed"
}

export interface TestResult {
  id: string
  user_id: string
  test_id: string
  score: number
  answers: Record<string, number>
  time_taken: number | null
  started_at: string | null
  completed_at: string
}

export interface TestWithQuestions extends Test {
  questions: Question[]
}

export interface UserWithTests extends User {
  tests: Test[]
}
