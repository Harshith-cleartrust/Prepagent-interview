// API Keys
export const GEMINI_API_KEY = "AIzaSyCnfO-ZAWb5p7i0fe6vZU2DaQ7BWWUujPc"

// Other constants
export const DEFAULT_TEST_DURATION = 60 // minutes
export const DEFAULT_QUESTION_COUNT = 30
