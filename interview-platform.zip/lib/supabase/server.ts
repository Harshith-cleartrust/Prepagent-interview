import { createClient } from "@supabase/supabase-js"

// Ensure environment variables are available
const supabaseUrl = process.env.SUPABASE_URL
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl || !supabaseServiceKey) {
  console.error("Missing Supabase environment variables. Please check your .env file.")
}

// Create a Supabase client with the service role key for server operations
export const supabaseServer = createClient(supabaseUrl || "", supabaseServiceKey || "")

// Also export a function to create a new client if needed
export const createServerClient = (cookieStore?: any) => {
  return createClient(supabaseUrl || "", supabaseServiceKey || "")
}
